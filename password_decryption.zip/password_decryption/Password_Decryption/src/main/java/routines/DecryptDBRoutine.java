package routines;
import org.jasypt.util.text.BasicTextEncryptor;

public class DecryptDBRoutine {
    public static String decrypt(String PassPhrase, String encryptedPassword) {
    	BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
        textEncryptor.setPassword(PassPhrase);
	return textEncryptor.decrypt(encryptedPassword);
    } 
} // end class
