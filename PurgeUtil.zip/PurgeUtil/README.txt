###PurgeUtil -- Utility to Purge old aging files and zip+archive lesser aging files based on the folderpath and pattern specified in params file

## Usage: /tdadm/bin/tdadm/tdadm_purgeutil_job.ksh <PURGE_PARAMS_FILE>
## 	where 
##	  PURGE_PARAMS_FILE  -- FileName with the complete path containing the rules for purging. This file should be placed under globalparams folder with name ending with *_PurgeUtil.params
## <PURGE_PARAMS_FILE> contains following details (first record is header)
## SeqNo|FilePath|FilePattern|ArchiveAge|PurgeAge
## SeqNo         - Unique Integer Value for each entry in <PURGE_PARAMS_FILE> 
## FilePath      - Folder from where the files are to be purged
## FilePattern   - Specify the pattern using wild entry(*) based on which files should be considered for purging
## ArchiveAge    - Takes an integer value. Files matching the <FilePattern> and older than <ArchiveAge> & greater than <PurgeAge> will be archived to a '_tempArchive_yyyyMMdd-HHmmss.gz' zip file under the <FilePath> folder
## PurgeAge      - Takes an integer value. Files matching the <FilePattern> or '_tempArchive_<SeqNo>' and older than <PurgeAge> will be deleted  

### Example content of <PURGE_PARAMS_FILE>

SeqNo|FilePath|FilePattern|ArchiveAge|PurgeAge
1|/tdgiw/CodeScan/report|*.xlsx|3|35
2|/tdgiw/CodeScan/log|*.log|3|35
3|/tdgiw/aml/projects/imr1911/run/J_AML_IMR1911_Main_v1/J_AML_IMR1911_Main_v1/context.temp|*|1|1
4|/tdgiw/aml/jobserver/Talend-JobServer-20150908_1633-V6.0.1/TalendJobServersFiles/archiveJobs|*.zip|3|5
