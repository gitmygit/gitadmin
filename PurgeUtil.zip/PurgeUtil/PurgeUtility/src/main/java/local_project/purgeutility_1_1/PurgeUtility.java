package local_project.purgeutility_1_1;

import routines.TalendDataGenerator;
import routines.CitiEncryptUtil;
import routines.GetRandomPhoneNum;
import routines.Numeric;
import routines.DelimiterCount;
import routines.DQTechnical;
import routines.MDM;
import routines.DemoRoutines;
import routines.MindTreeRoutines;
import routines.BigDecimalConvertion;
import routines.DataOperation;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.StringHandler;
import routines.SQLike;
import routines.CITIRoutine;
import routines.Normal2StandardDate;
import routines.TalendString;
import routines.MindTree;
import routines.StringHandling;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.KeyManagementForSqoop;
import routines.PRGHASH;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

//the import part of tJavaRow_2
//import java.util.List;

//the import part of tJava_1
//import java.util.List;

//the import part of tJavaRow_3
//import java.util.List;

//the import part of tJava_2
//import java.util.List;

@SuppressWarnings("unused")
/**
 * Job: PurgeUtility Purpose: <br>
 * Description:  <br>
 * @author admin@citi.com
 * @version 6.0.1.20151110_1633_patch
 * @status 
 */
public class PurgeUtility implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "PurgeUtility.log");
	}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger
			.getLogger(PurgeUtility.class);

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset
			.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (FolderPath != null) {

				this.setProperty("FolderPath", FolderPath.toString());

			}

			if (FilePattern != null) {

				this.setProperty("FilePattern", FilePattern.toString());

			}

			if (PurgeDayOld != null) {

				this.setProperty("PurgeDayOld", PurgeDayOld.toString());

			}

			if (DelFilePath != null) {

				this.setProperty("DelFilePath", DelFilePath.toString());

			}

			if (ArchiveDayOld != null) {

				this.setProperty("ArchiveDayOld", ArchiveDayOld.toString());

			}

			if (ArchiveFileList != null) {

				this.setProperty("ArchiveFileList", ArchiveFileList.toString());

			}

			if (ArchiveFilePath != null) {

				this.setProperty("ArchiveFilePath", ArchiveFilePath.toString());

			}

			if (ArchiveFileName != null) {

				this.setProperty("ArchiveFileName", ArchiveFileName.toString());

			}

			if (SeqNo != null) {

				this.setProperty("SeqNo", SeqNo.toString());

			}

		}

		public String FolderPath;

		public String getFolderPath() {
			return this.FolderPath;
		}

		public String FilePattern;

		public String getFilePattern() {
			return this.FilePattern;
		}

		public Integer PurgeDayOld;

		public Integer getPurgeDayOld() {
			return this.PurgeDayOld;
		}

		public String DelFilePath;

		public String getDelFilePath() {
			return this.DelFilePath;
		}

		public Integer ArchiveDayOld;

		public Integer getArchiveDayOld() {
			return this.ArchiveDayOld;
		}

		public String ArchiveFileList;

		public String getArchiveFileList() {
			return this.ArchiveFileList;
		}

		public String ArchiveFilePath;

		public String getArchiveFilePath() {
			return this.ArchiveFilePath;
		}

		public String ArchiveFileName;

		public String getArchiveFileName() {
			return this.ArchiveFileName;
		}

		public Integer SeqNo;

		public Integer getSeqNo() {
			return this.SeqNo;
		}
	}

	private ContextProperties context = new ContextProperties();

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "1.1";
	private final String jobName = "PurgeUtility";
	private final String projectName = "LOCAL_PROJECT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	public boolean isExportedAsOSGI = false;

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(
			java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources
				.entrySet()) {
			talendDataSources.put(
					dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry
							.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null
						&& currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE",
							getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE",
						getExceptionCauseMessage(e));
				System.err
						.println("Exception in component " + currentComponent);
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					PurgeUtility.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(PurgeUtility.this, new Object[] { e,
									currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileList_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileList_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileProperties_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileList_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileList_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileDelete_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		try {

			errorCode = null;
			tJava_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		tFileList_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileList_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tJava_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tBufferOutput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileList_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tBufferInput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBufferInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBufferInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tJava_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSystem_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tSystem_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDenormalize_2_DenormalizeOut_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		tDenormalize_2_ArrayIn_error(exception, errorComponent, globalMap);

	}

	public void tDenormalize_2_ArrayIn_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBufferInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileList_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tBufferInput_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tSystem_3_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row3Struct implements
			routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String abs_path;

		public String getAbs_path() {
			return this.abs_path;
		}

		public java.util.Date newColumn;

		public java.util.Date getNewColumn() {
			return this.newColumn;
		}

		public Long mtime;

		public Long getMtime() {
			return this.mtime;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.abs_path = readString(dis);

					this.newColumn = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.mtime = null;
					} else {
						this.mtime = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.abs_path, dos);

				// java.util.Date

				writeDate(this.newColumn, dos);

				// Long

				if (this.mtime == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.mtime);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("abs_path=" + abs_path);
			sb.append(",newColumn=" + String.valueOf(newColumn));
			sb.append(",mtime=" + String.valueOf(mtime));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (abs_path == null) {
				sb.append("<null>");
			} else {
				sb.append(abs_path);
			}

			sb.append("|");

			if (newColumn == null) {
				sb.append("<null>");
			} else {
				sb.append(newColumn);
			}

			sb.append("|");

			if (mtime == null) {
				sb.append("<null>");
			} else {
				sb.append(mtime);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class filteredFilesStruct implements
			routines.system.IPersistableRow<filteredFilesStruct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String abs_path;

		public String getAbs_path() {
			return this.abs_path;
		}

		public java.util.Date newColumn;

		public java.util.Date getNewColumn() {
			return this.newColumn;
		}

		public Long mtime;

		public Long getMtime() {
			return this.mtime;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.abs_path = readString(dis);

					this.newColumn = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.mtime = null;
					} else {
						this.mtime = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.abs_path, dos);

				// java.util.Date

				writeDate(this.newColumn, dos);

				// Long

				if (this.mtime == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.mtime);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("abs_path=" + abs_path);
			sb.append(",newColumn=" + String.valueOf(newColumn));
			sb.append(",mtime=" + String.valueOf(mtime));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (abs_path == null) {
				sb.append("<null>");
			} else {
				sb.append(abs_path);
			}

			sb.append("|");

			if (newColumn == null) {
				sb.append("<null>");
			} else {
				sb.append(newColumn);
			}

			sb.append("|");

			if (mtime == null) {
				sb.append("<null>");
			} else {
				sb.append(mtime);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(filteredFilesStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ArchivePathStruct implements
			routines.system.IPersistableRow<ArchivePathStruct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String dirname;

		public String getDirname() {
			return this.dirname;
		}

		public String basename;

		public String getBasename() {
			return this.basename;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.dirname = readString(dis);

					this.basename = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.dirname, dos);

				// String

				writeString(this.basename, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("dirname=" + dirname);
			sb.append(",basename=" + basename);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (dirname == null) {
				sb.append("<null>");
			} else {
				sb.append(dirname);
			}

			sb.append("|");

			if (basename == null) {
				sb.append("<null>");
			} else {
				sb.append(basename);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ArchivePathStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String abs_path;

		public String getAbs_path() {
			return this.abs_path;
		}

		public String dirname;

		public String getDirname() {
			return this.dirname;
		}

		public String basename;

		public String getBasename() {
			return this.basename;
		}

		public String mode_string;

		public String getMode_string() {
			return this.mode_string;
		}

		public Long size;

		public Long getSize() {
			return this.size;
		}

		public Long mtime;

		public Long getMtime() {
			return this.mtime;
		}

		public String mtime_string;

		public String getMtime_string() {
			return this.mtime_string;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.abs_path = readString(dis);

					this.dirname = readString(dis);

					this.basename = readString(dis);

					this.mode_string = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.size = null;
					} else {
						this.size = dis.readLong();
					}

					length = dis.readByte();
					if (length == -1) {
						this.mtime = null;
					} else {
						this.mtime = dis.readLong();
					}

					this.mtime_string = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.abs_path, dos);

				// String

				writeString(this.dirname, dos);

				// String

				writeString(this.basename, dos);

				// String

				writeString(this.mode_string, dos);

				// Long

				if (this.size == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.size);
				}

				// Long

				if (this.mtime == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.mtime);
				}

				// String

				writeString(this.mtime_string, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("abs_path=" + abs_path);
			sb.append(",dirname=" + dirname);
			sb.append(",basename=" + basename);
			sb.append(",mode_string=" + mode_string);
			sb.append(",size=" + String.valueOf(size));
			sb.append(",mtime=" + String.valueOf(mtime));
			sb.append(",mtime_string=" + mtime_string);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (abs_path == null) {
				sb.append("<null>");
			} else {
				sb.append(abs_path);
			}

			sb.append("|");

			if (dirname == null) {
				sb.append("<null>");
			} else {
				sb.append(dirname);
			}

			sb.append("|");

			if (basename == null) {
				sb.append("<null>");
			} else {
				sb.append(basename);
			}

			sb.append("|");

			if (mode_string == null) {
				sb.append("<null>");
			} else {
				sb.append(mode_string);
			}

			sb.append("|");

			if (size == null) {
				sb.append("<null>");
			} else {
				sb.append(size);
			}

			sb.append("|");

			if (mtime == null) {
				sb.append("<null>");
			} else {
				sb.append(mtime);
			}

			sb.append("|");

			if (mtime_string == null) {
				sb.append("<null>");
			} else {
				sb.append(mtime_string);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileList_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileList_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				filteredFilesStruct filteredFiles = new filteredFilesStruct();
				filteredFilesStruct row3 = filteredFiles;
				ArchivePathStruct ArchivePath = new ArchivePathStruct();

				/**
				 * [tFileList_1 begin ] start
				 */

				int NB_ITERATE_tFileProperties_1 = 0; // for statistics

				ok_Hash.put("tFileList_1", false);
				start_Hash.put("tFileList_1", System.currentTimeMillis());

				currentComponent = "tFileList_1";

				int tos_count_tFileList_1 = 0;

				if (log.isInfoEnabled())
					log.info("tFileList_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileList_1 = new StringBuilder();
				log4jParamters_tFileList_1.append("Parameters:");
				log4jParamters_tFileList_1.append("DIRECTORY" + " = "
						+ "context.FolderPath");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1
						.append("LIST_MODE" + " = " + "FILES");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("INCLUDSUBDIR" + " = "
						+ "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("CASE_SENSITIVE" + " = "
						+ "NO");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ERROR" + " = " + "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("GLOBEXPRESSIONS" + " = "
						+ "true");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("FILES" + " = "
						+ "[{FILEMASK=" + ("context.FilePattern")
						+ "}, {FILEMASK="
						+ ("\"_tempArchive_\"+context.SeqNo+\"_*\"") + "}]");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ORDER_BY_NOTHING" + " = "
						+ "true");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ORDER_BY_FILENAME" + " = "
						+ "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ORDER_BY_FILESIZE" + " = "
						+ "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ORDER_BY_MODIFIEDDATE"
						+ " = " + "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ORDER_ACTION_ASC" + " = "
						+ "true");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("ORDER_ACTION_DESC" + " = "
						+ "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1
						.append("IFEXCLUDE" + " = " + "false");
				log4jParamters_tFileList_1.append(" | ");
				log4jParamters_tFileList_1.append("FORMAT_FILEPATH_TO_SLASH"
						+ " = " + "false");
				log4jParamters_tFileList_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileList_1 - " + log4jParamters_tFileList_1);

				final StringBuffer log4jSb_tFileList_1 = new StringBuffer();

				String directory_tFileList_1 = context.FolderPath;
				final java.util.List<String> maskList_tFileList_1 = new java.util.ArrayList<String>();
				final java.util.List<java.util.regex.Pattern> patternList_tFileList_1 = new java.util.ArrayList<java.util.regex.Pattern>();
				maskList_tFileList_1.add(context.FilePattern);
				maskList_tFileList_1
						.add("_tempArchive_" + context.SeqNo + "_*");
				for (final String filemask_tFileList_1 : maskList_tFileList_1) {
					String filemask_compile_tFileList_1 = filemask_tFileList_1;

					filemask_compile_tFileList_1 = org.apache.oro.text.GlobCompiler
							.globToPerl5(
									filemask_tFileList_1.toCharArray(),
									org.apache.oro.text.GlobCompiler.DEFAULT_MASK);

					java.util.regex.Pattern fileNamePattern_tFileList_1 = java.util.regex.Pattern
							.compile(filemask_compile_tFileList_1,
									java.util.regex.Pattern.CASE_INSENSITIVE);

					patternList_tFileList_1.add(fileNamePattern_tFileList_1);
				}
				int NB_FILEtFileList_1 = 0;

				final boolean case_sensitive_tFileList_1 = false;
				final java.util.List<java.io.File> list_tFileList_1 = new java.util.ArrayList<java.io.File>();
				final java.util.Set<String> filePath_tFileList_1 = new java.util.HashSet<String>();
				java.io.File file_tFileList_1 = new java.io.File(
						directory_tFileList_1);

				file_tFileList_1.listFiles(new java.io.FilenameFilter() {
					public boolean accept(java.io.File dir, String name) {
						java.io.File file = new java.io.File(dir, name);
						if (!file.isDirectory()) {

							String fileName_tFileList_1 = file.getName();
							for (final java.util.regex.Pattern fileNamePattern_tFileList_1 : patternList_tFileList_1) {
								if (fileNamePattern_tFileList_1.matcher(
										fileName_tFileList_1).matches()) {
									if (!filePath_tFileList_1.contains(file
											.getAbsolutePath())) {
										list_tFileList_1.add(file);
										filePath_tFileList_1.add(file
												.getAbsolutePath());
									}
								}
							}
						}
						return true;
					}
				});
				java.util.Collections.sort(list_tFileList_1);

				log.info("tFileList_1 - Start to list files");

				for (int i_tFileList_1 = 0; i_tFileList_1 < list_tFileList_1
						.size(); i_tFileList_1++) {
					java.io.File files_tFileList_1 = list_tFileList_1
							.get(i_tFileList_1);
					String fileName_tFileList_1 = files_tFileList_1.getName();

					String currentFileName_tFileList_1 = files_tFileList_1
							.getName();
					String currentFilePath_tFileList_1 = files_tFileList_1
							.getAbsolutePath();
					String currentFileDirectory_tFileList_1 = files_tFileList_1
							.getParent();
					String currentFileExtension_tFileList_1 = null;

					if (files_tFileList_1.getName().contains(".")
							&& files_tFileList_1.isFile()) {
						currentFileExtension_tFileList_1 = files_tFileList_1
								.getName().substring(
										files_tFileList_1.getName()
												.lastIndexOf(".") + 1);
					} else {
						currentFileExtension_tFileList_1 = "";
					}

					NB_FILEtFileList_1++;
					globalMap.put("tFileList_1_CURRENT_FILE",
							currentFileName_tFileList_1);
					globalMap.put("tFileList_1_CURRENT_FILEPATH",
							currentFilePath_tFileList_1);
					globalMap.put("tFileList_1_CURRENT_FILEDIRECTORY",
							currentFileDirectory_tFileList_1);
					globalMap.put("tFileList_1_CURRENT_FILEEXTENSION",
							currentFileExtension_tFileList_1);
					globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);

					log.info("tFileList_1 - Current file or directory path : "
							+ currentFilePath_tFileList_1);

					/**
					 * [tFileList_1 begin ] stop
					 */

					/**
					 * [tFileList_1 main ] start
					 */

					currentComponent = "tFileList_1";

					tos_count_tFileList_1++;

					/**
					 * [tFileList_1 main ] stop
					 */
					NB_ITERATE_tFileProperties_1++;

					/**
					 * [tJavaRow_2 begin ] start
					 */

					ok_Hash.put("tJavaRow_2", false);
					start_Hash.put("tJavaRow_2", System.currentTimeMillis());

					currentComponent = "tJavaRow_2";

					int tos_count_tJavaRow_2 = 0;

					int nb_line_tJavaRow_2 = 0;

					/**
					 * [tJavaRow_2 begin ] stop
					 */

					/**
					 * [tFileDelete_1 begin ] start
					 */

					ok_Hash.put("tFileDelete_1", false);
					start_Hash.put("tFileDelete_1", System.currentTimeMillis());

					currentComponent = "tFileDelete_1";

					int tos_count_tFileDelete_1 = 0;

					if (log.isInfoEnabled())
						log.info("tFileDelete_1 - " + "Start to work.");
					StringBuilder log4jParamters_tFileDelete_1 = new StringBuilder();
					log4jParamters_tFileDelete_1.append("Parameters:");
					log4jParamters_tFileDelete_1.append("FILENAME" + " = "
							+ "context.DelFilePath");
					log4jParamters_tFileDelete_1.append(" | ");
					log4jParamters_tFileDelete_1.append("FAILON" + " = "
							+ "false");
					log4jParamters_tFileDelete_1.append(" | ");
					log4jParamters_tFileDelete_1.append("FOLDER" + " = "
							+ "false");
					log4jParamters_tFileDelete_1.append(" | ");
					log4jParamters_tFileDelete_1.append("FOLDER_FILE" + " = "
							+ "false");
					log4jParamters_tFileDelete_1.append(" | ");
					if (log.isDebugEnabled())
						log.debug("tFileDelete_1 - "
								+ log4jParamters_tFileDelete_1);

					/**
					 * [tFileDelete_1 begin ] stop
					 */

					/**
					 * [tBufferOutput_1 begin ] start
					 */

					ok_Hash.put("tBufferOutput_1", false);
					start_Hash.put("tBufferOutput_1",
							System.currentTimeMillis());

					currentComponent = "tBufferOutput_1";

					int tos_count_tBufferOutput_1 = 0;

					/**
					 * [tBufferOutput_1 begin ] stop
					 */

					/**
					 * [tMap_1 begin ] start
					 */

					ok_Hash.put("tMap_1", false);
					start_Hash.put("tMap_1", System.currentTimeMillis());

					currentComponent = "tMap_1";

					int tos_count_tMap_1 = 0;

					if (log.isInfoEnabled())
						log.info("tMap_1 - " + "Start to work.");
					StringBuilder log4jParamters_tMap_1 = new StringBuilder();
					log4jParamters_tMap_1.append("Parameters:");
					log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
					log4jParamters_tMap_1.append(" | ");
					log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY"
							+ " = " + "");
					log4jParamters_tMap_1.append(" | ");
					log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = "
							+ "2000000");
					log4jParamters_tMap_1.append(" | ");
					log4jParamters_tMap_1
							.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL"
									+ " = " + "false");
					log4jParamters_tMap_1.append(" | ");
					if (log.isDebugEnabled())
						log.debug("tMap_1 - " + log4jParamters_tMap_1);

					// ###############################
					// # Lookup's keys initialization
					int count_row1_tMap_1 = 0;

					// ###############################

					// ###############################
					// # Vars initialization
					class Var__tMap_1__Struct {
						java.util.Date varFileDate;
						java.util.Date varOldDate;
						java.util.Date varArchiveDate;
					}
					Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
					// ###############################

					// ###############################
					// # Outputs initialization
					int count_filteredFiles_tMap_1 = 0;

					filteredFilesStruct filteredFiles_tmp = new filteredFilesStruct();
					int count_ArchivePath_tMap_1 = 0;

					ArchivePathStruct ArchivePath_tmp = new ArchivePathStruct();
					// ###############################

					/**
					 * [tMap_1 begin ] stop
					 */

					/**
					 * [tFileProperties_1 begin ] start
					 */

					ok_Hash.put("tFileProperties_1", false);
					start_Hash.put("tFileProperties_1",
							System.currentTimeMillis());

					currentComponent = "tFileProperties_1";

					int tos_count_tFileProperties_1 = 0;

					if (log.isInfoEnabled())
						log.info("tFileProperties_1 - " + "Start to work.");
					StringBuilder log4jParamters_tFileProperties_1 = new StringBuilder();
					log4jParamters_tFileProperties_1.append("Parameters:");
					log4jParamters_tFileProperties_1
							.append("FILENAME"
									+ " = "
									+ "((String)globalMap.get(\"tFileList_1_CURRENT_FILEPATH\"))");
					log4jParamters_tFileProperties_1.append(" | ");
					log4jParamters_tFileProperties_1.append("MD5" + " = "
							+ "false");
					log4jParamters_tFileProperties_1.append(" | ");
					if (log.isDebugEnabled())
						log.debug("tFileProperties_1 - "
								+ log4jParamters_tFileProperties_1);

					final StringBuffer log4jSb_tFileProperties_1 = new StringBuffer();

					java.io.File file_tFileProperties_1 = new java.io.File(
							((String) globalMap
									.get("tFileList_1_CURRENT_FILEPATH")));
					row1 = new row1Struct();

					if (file_tFileProperties_1.exists()) {
						row1.abs_path = file_tFileProperties_1
								.getAbsolutePath();
						row1.dirname = file_tFileProperties_1.getParent();
						row1.basename = file_tFileProperties_1.getName();
						String r_tFileProperties_1 = (file_tFileProperties_1
								.canRead()) ? "r" : "-";
						String w_tFileProperties_1 = (file_tFileProperties_1
								.canWrite()) ? "w" : "-";
						// String x_ = (file_.canExecute())?"x":"-"; /*since
						// JDK1.6*/
						row1.mode_string = r_tFileProperties_1
								+ w_tFileProperties_1;
						row1.size = file_tFileProperties_1.length();
						row1.mtime = file_tFileProperties_1.lastModified();
						row1.mtime_string = (new java.util.Date(
								file_tFileProperties_1.lastModified()))
								.toString();

					} else {
						log.info("tFileProperties_1 - File : "
								+ file_tFileProperties_1.getAbsolutePath()
								+ " doesn't exist.");
					}

					/**
					 * [tFileProperties_1 begin ] stop
					 */

					/**
					 * [tFileProperties_1 main ] start
					 */

					currentComponent = "tFileProperties_1";

					tos_count_tFileProperties_1++;

					/**
					 * [tFileProperties_1 main ] stop
					 */

					/**
					 * [tMap_1 main ] start
					 */

					currentComponent = "tMap_1";

					if (log.isTraceEnabled()) {
						log.trace("row1 - "
								+ (row1 == null ? "" : row1.toLogString()));
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_1 = false;
					boolean mainRowRejected_tMap_1 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_1__Struct Var = Var__tMap_1;
						Var.varFileDate = new java.util.Date(
								(long) (row1.mtime));
						Var.varOldDate = TalendDate.addDate(
								TalendDate.getCurrentDate(),
								-context.PurgeDayOld, "dd");
						Var.varArchiveDate = TalendDate.addDate(
								TalendDate.getCurrentDate(),
								-context.ArchiveDayOld, "dd");// ###############################
						// ###############################
						// # Output tables

						filteredFiles = null;
						ArchivePath = null;

						// # Output table : 'filteredFiles'
						// # Filter conditions
						if (

						Var.varFileDate.before(Var.varOldDate) == true

						) {
							count_filteredFiles_tMap_1++;

							filteredFiles_tmp.abs_path = context.DelFilePath = row1.abs_path;
							filteredFiles_tmp.newColumn = Var.varFileDate;
							filteredFiles_tmp.mtime = row1.mtime;
							filteredFiles = filteredFiles_tmp;
							log.debug("tMap_1 - Outputting the record "
									+ count_filteredFiles_tMap_1
									+ " of the output table 'filteredFiles'.");

						} // closing filter/reject

						// # Output table : 'ArchivePath'
						// # Filter conditions
						if (

						Var.varFileDate.before(Var.varArchiveDate) == true
								&& !row1.basename.startsWith("_tempArchive_")
								&& Var.varFileDate.before(Var.varOldDate) == false

						) {
							count_ArchivePath_tMap_1++;

							ArchivePath_tmp.dirname = row1.dirname;
							ArchivePath_tmp.basename = row1.basename;
							ArchivePath = ArchivePath_tmp;
							log.debug("tMap_1 - Outputting the record "
									+ count_ArchivePath_tMap_1
									+ " of the output table 'ArchivePath'.");

						} // closing filter/reject
							// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_1 = false;

					tos_count_tMap_1++;

					/**
					 * [tMap_1 main ] stop
					 */
					// Start of branch "filteredFiles"
					if (filteredFiles != null) {

						/**
						 * [tFileDelete_1 main ] start
						 */

						currentComponent = "tFileDelete_1";

						if (log.isTraceEnabled()) {
							log.trace("filteredFiles - "
									+ (filteredFiles == null ? ""
											: filteredFiles.toLogString()));
						}

						final StringBuffer log4jSb_tFileDelete_1 = new StringBuffer();

						class DeleteFoldertFileDelete_1 {
							/**
							 * delete all the sub-files in 'file'
							 * 
							 * @param file
							 */
							public boolean delete(java.io.File file) {
								java.io.File[] files = file.listFiles();
								for (int i = 0; i < files.length; i++) {
									if (files[i].isFile()) {
										files[i].delete();
									} else if (files[i].isDirectory()) {
										if (!files[i].delete()) {
											delete(files[i]);
										}
									}
								}
								deleteDirectory(file);
								return file.delete();
							}

							/**
							 * delete all the sub-folders in 'file'
							 * 
							 * @param file
							 */
							private void deleteDirectory(java.io.File file) {
								java.io.File[] filed = file.listFiles();
								for (int i = 0; i < filed.length; i++) {
									if (filed[i].isDirectory()) {
										deleteDirectory(filed[i]);
									}
									filed[i].delete();
								}
							}

						}
						java.io.File file_tFileDelete_1 = new java.io.File(
								context.DelFilePath);
						if (file_tFileDelete_1.exists()
								&& file_tFileDelete_1.isFile()) {
							if (file_tFileDelete_1.delete()) {
								globalMap.put("tFileDelete_1_CURRENT_STATUS",
										"File deleted.");
								log.info("tFileDelete_1 - File : "
										+ file_tFileDelete_1.getAbsolutePath()
										+ " is deleted.");
							} else {
								globalMap.put("tFileDelete_1_CURRENT_STATUS",
										"No file deleted.");
								log.info("tFileDelete_1 - Fail to delete file : "
										+ file_tFileDelete_1.getAbsolutePath());
							}
						} else {
							globalMap.put("tFileDelete_1_CURRENT_STATUS",
									"File does not exist or is invalid.");
							log.error("tFileDelete_1 - "
									+ file_tFileDelete_1.getAbsolutePath()
									+ " does not exist or is invalid or is not a file.");
						}
						globalMap.put("tFileDelete_1_DELETE_PATH",
								context.DelFilePath);

						row3 = filteredFiles;

						tos_count_tFileDelete_1++;

						/**
						 * [tFileDelete_1 main ] stop
						 */

						/**
						 * [tJavaRow_2 main ] start
						 */

						currentComponent = "tJavaRow_2";

						if (log.isTraceEnabled()) {
							log.trace("row3 - "
									+ (row3 == null ? "" : row3.toLogString()));
						}

						// code sample:
						//
						// multiply by 2 the row identifier
						// output_row.id = row3.id * 2;
						//
						// lowercase the name
						// output_row.name = row3.name.toLowerCase();
						// System.out.println(((String)globalMap.get("tFileDelete_1_CURRENT_STATUS")));
						System.out.println(((String) globalMap
								.get("tFileDelete_1_DELETE_PATH"))
								+ " "
								+ ((String) globalMap
										.get("tFileDelete_1_CURRENT_STATUS")));

						nb_line_tJavaRow_2++;

						tos_count_tJavaRow_2++;

						/**
						 * [tJavaRow_2 main ] stop
						 */

					} // End of branch "filteredFiles"

					// Start of branch "ArchivePath"
					if (ArchivePath != null) {

						/**
						 * [tBufferOutput_1 main ] start
						 */

						currentComponent = "tBufferOutput_1";

						if (log.isTraceEnabled()) {
							log.trace("ArchivePath - "
									+ (ArchivePath == null ? "" : ArchivePath
											.toLogString()));
						}

						String[] row_tBufferOutput_1 = new String[] { "", "", };
						if (ArchivePath.dirname != null) {

							row_tBufferOutput_1[0] = ArchivePath.dirname;

						} else {
							row_tBufferOutput_1[0] = null;
						}
						if (ArchivePath.basename != null) {

							row_tBufferOutput_1[1] = ArchivePath.basename;

						} else {
							row_tBufferOutput_1[1] = null;
						}
						globalBuffer.add(row_tBufferOutput_1);

						tos_count_tBufferOutput_1++;

						/**
						 * [tBufferOutput_1 main ] stop
						 */

					} // End of branch "ArchivePath"

					/**
					 * [tFileProperties_1 end ] start
					 */

					currentComponent = "tFileProperties_1";

					if (log.isInfoEnabled())
						log.info("tFileProperties_1 - " + "Done.");

					ok_Hash.put("tFileProperties_1", true);
					end_Hash.put("tFileProperties_1",
							System.currentTimeMillis());

					/**
					 * [tFileProperties_1 end ] stop
					 */

					/**
					 * [tMap_1 end ] start
					 */

					currentComponent = "tMap_1";

					// ###############################
					// # Lookup hashes releasing
					// ###############################
					log.debug("tMap_1 - Written records count in the table 'filteredFiles': "
							+ count_filteredFiles_tMap_1 + ".");
					log.debug("tMap_1 - Written records count in the table 'ArchivePath': "
							+ count_ArchivePath_tMap_1 + ".");

					if (log.isInfoEnabled())
						log.info("tMap_1 - " + "Done.");

					ok_Hash.put("tMap_1", true);
					end_Hash.put("tMap_1", System.currentTimeMillis());

					/**
					 * [tMap_1 end ] stop
					 */

					/**
					 * [tFileDelete_1 end ] start
					 */

					currentComponent = "tFileDelete_1";

					if (log.isInfoEnabled())
						log.info("tFileDelete_1 - " + "Done.");

					ok_Hash.put("tFileDelete_1", true);
					end_Hash.put("tFileDelete_1", System.currentTimeMillis());

					/**
					 * [tFileDelete_1 end ] stop
					 */

					/**
					 * [tJavaRow_2 end ] start
					 */

					currentComponent = "tJavaRow_2";

					globalMap.put("tJavaRow_2_NB_LINE", nb_line_tJavaRow_2);

					ok_Hash.put("tJavaRow_2", true);
					end_Hash.put("tJavaRow_2", System.currentTimeMillis());

					/**
					 * [tJavaRow_2 end ] stop
					 */

					/**
					 * [tBufferOutput_1 end ] start
					 */

					currentComponent = "tBufferOutput_1";

					ok_Hash.put("tBufferOutput_1", true);
					end_Hash.put("tBufferOutput_1", System.currentTimeMillis());

					/**
					 * [tBufferOutput_1 end ] stop
					 */

					/**
					 * [tFileList_1 end ] start
					 */

					currentComponent = "tFileList_1";

				}
				globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);

				log.info("tFileList_1 - File or directory count : "
						+ NB_FILEtFileList_1);

				if (log.isInfoEnabled())
					log.info("tFileList_1 - " + "Done.");

				ok_Hash.put("tFileList_1", true);
				end_Hash.put("tFileList_1", System.currentTimeMillis());

				/**
				 * [tFileList_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tFileList_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tBufferInput_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tFileList_1 finally ] start
				 */

				currentComponent = "tFileList_1";

				/**
				 * [tFileList_1 finally ] stop
				 */

				/**
				 * [tFileProperties_1 finally ] start
				 */

				currentComponent = "tFileProperties_1";

				/**
				 * [tFileProperties_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tFileDelete_1 finally ] start
				 */

				currentComponent = "tFileDelete_1";

				/**
				 * [tFileDelete_1 finally ] stop
				 */

				/**
				 * [tJavaRow_2 finally ] start
				 */

				currentComponent = "tJavaRow_2";

				/**
				 * [tJavaRow_2 finally ] stop
				 */

				/**
				 * [tBufferOutput_1 finally ] start
				 */

				currentComponent = "tBufferOutput_1";

				/**
				 * [tBufferOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileList_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_1 begin ] start
				 */

				ok_Hash.put("tJava_1", false);
				start_Hash.put("tJava_1", System.currentTimeMillis());

				currentComponent = "tJava_1";

				int tos_count_tJava_1 = 0;

				System.out.println(((String) globalMap
						.get("tFileDelete_1_ERROR_MESSAGE")));

				/**
				 * [tJava_1 begin ] stop
				 */

				/**
				 * [tJava_1 main ] start
				 */

				currentComponent = "tJava_1";

				tos_count_tJava_1++;

				/**
				 * [tJava_1 main ] stop
				 */

				/**
				 * [tJava_1 end ] start
				 */

				currentComponent = "tJava_1";

				ok_Hash.put("tJava_1", true);
				end_Hash.put("tJava_1", System.currentTimeMillis());

				/**
				 * [tJava_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_1 finally ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}

	public static class row7Struct implements
			routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String dirname;

		public String getDirname() {
			return this.dirname;
		}

		public String basename;

		public String getBasename() {
			return this.basename;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.dirname = readString(dis);

					this.basename = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.dirname, dos);

				// String

				writeString(this.basename, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("dirname=" + dirname);
			sb.append(",basename=" + basename);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (dirname == null) {
				sb.append("<null>");
			} else {
				sb.append(dirname);
			}

			sb.append("|");

			if (basename == null) {
				sb.append("<null>");
			} else {
				sb.append(basename);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtDenormalize_2 implements
			routines.system.IPersistableRow<OnRowsEndStructtDenormalize_2> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String dirname;

		public String getDirname() {
			return this.dirname;
		}

		public String basename;

		public String getBasename() {
			return this.basename;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.dirname = readString(dis);

					this.basename = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.dirname, dos);

				// String

				writeString(this.basename, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("dirname=" + dirname);
			sb.append(",basename=" + basename);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (dirname == null) {
				sb.append("<null>");
			} else {
				sb.append(dirname);
			}

			sb.append("|");

			if (basename == null) {
				sb.append("<null>");
			} else {
				sb.append(basename);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtDenormalize_2 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements
			routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_PurgeUtility = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[0];

		public String dirname;

		public String getDirname() {
			return this.dirname;
		}

		public String basename;

		public String getBasename() {
			return this.basename;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_PurgeUtility.length) {
					if (length < 1024
							&& commonByteArray_LOCAL_PROJECT_PurgeUtility.length == 0) {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_PurgeUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_PurgeUtility, 0,
						length);
				strReturn = new String(
						commonByteArray_LOCAL_PROJECT_PurgeUtility, 0, length,
						utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_PurgeUtility) {

				try {

					int length = 0;

					this.dirname = readString(dis);

					this.basename = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.dirname, dos);

				// String

				writeString(this.basename, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("dirname=" + dirname);
			sb.append(",basename=" + basename);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (dirname == null) {
				sb.append("<null>");
			} else {
				sb.append(dirname);
			}

			sb.append("|");

			if (basename == null) {
				sb.append("<null>");
			} else {
				sb.append(basename);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tBufferInput_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tBufferInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row8Struct row8 = new row8Struct();
				row7Struct row7 = new row7Struct();

				/**
				 * [tDenormalize_2_DenormalizeOut begin ] start
				 */

				ok_Hash.put("tDenormalize_2_DenormalizeOut", false);
				start_Hash.put("tDenormalize_2_DenormalizeOut",
						System.currentTimeMillis());

				currentVirtualComponent = "tDenormalize_2";

				currentComponent = "tDenormalize_2_DenormalizeOut";

				int tos_count_tDenormalize_2_DenormalizeOut = 0;

				if (log.isInfoEnabled())
					log.info("tDenormalize_2_DenormalizeOut - "
							+ "Start to work.");
				StringBuilder log4jParamters_tDenormalize_2_DenormalizeOut = new StringBuilder();
				log4jParamters_tDenormalize_2_DenormalizeOut
						.append("Parameters:");
				log4jParamters_tDenormalize_2_DenormalizeOut
						.append("DESTINATION" + " = " + "tDenormalize_2");
				log4jParamters_tDenormalize_2_DenormalizeOut.append(" | ");
				log4jParamters_tDenormalize_2_DenormalizeOut
						.append("DENORMALIZE_COLUMNS" + " = " + "[{MERGE="
								+ ("false") + ", INPUT_COLUMN=" + ("basename")
								+ ", DELIMITER=" + ("\" \"") + "}]");
				log4jParamters_tDenormalize_2_DenormalizeOut.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tDenormalize_2_DenormalizeOut - "
							+ log4jParamters_tDenormalize_2_DenormalizeOut);

				class DenormalizeStructtDenormalize_2_DenormalizeOut {
					StringBuilder basename = new StringBuilder();
				}
				DenormalizeStructtDenormalize_2_DenormalizeOut denormalize_result_tDenormalize_2_DenormalizeOut = null;
				java.util.Map<String, DenormalizeStructtDenormalize_2_DenormalizeOut> hash_dirname_tDenormalize_2_DenormalizeOut = new java.util.HashMap<String, DenormalizeStructtDenormalize_2_DenormalizeOut>();
				log.info("tDenormalize_2_DenormalizeOut - Start to denormalize the data from datasource.");

				/**
				 * [tDenormalize_2_DenormalizeOut begin ] stop
				 */

				/**
				 * [tBufferInput_1 begin ] start
				 */

				ok_Hash.put("tBufferInput_1", false);
				start_Hash.put("tBufferInput_1", System.currentTimeMillis());

				currentComponent = "tBufferInput_1";

				int tos_count_tBufferInput_1 = 0;

				int nb_line_tBufferInput_1 = 0;

				String[] row_tBufferInput_1 = new String[2];
				for (int n = 0; n < globalBuffer.size(); n++) {
					row_tBufferInput_1 = (String[]) globalBuffer.get(n);
					if (0 < row_tBufferInput_1.length) {

						row8.dirname = row_tBufferInput_1[0];

					}

					else {
						row8.dirname = null;
					}
					if (1 < row_tBufferInput_1.length) {

						row8.basename = row_tBufferInput_1[1];

					}

					else {
						row8.basename = null;
					}

					/**
					 * [tBufferInput_1 begin ] stop
					 */

					/**
					 * [tBufferInput_1 main ] start
					 */

					currentComponent = "tBufferInput_1";

					tos_count_tBufferInput_1++;

					/**
					 * [tBufferInput_1 main ] stop
					 */

					/**
					 * [tDenormalize_2_DenormalizeOut main ] start
					 */

					currentVirtualComponent = "tDenormalize_2";

					currentComponent = "tDenormalize_2_DenormalizeOut";

					if (log.isTraceEnabled()) {
						log.trace("row8 - "
								+ (row8 == null ? "" : row8.toLogString()));
					}

					if (hash_dirname_tDenormalize_2_DenormalizeOut
							.containsKey(row8.dirname)) {
						denormalize_result_tDenormalize_2_DenormalizeOut = hash_dirname_tDenormalize_2_DenormalizeOut
								.get(row8.dirname);
						denormalize_result_tDenormalize_2_DenormalizeOut.basename
								.append(" ").append(row8.basename);

					} else {
						denormalize_result_tDenormalize_2_DenormalizeOut = new DenormalizeStructtDenormalize_2_DenormalizeOut();
						denormalize_result_tDenormalize_2_DenormalizeOut.basename
								.append(row8.basename);

						hash_dirname_tDenormalize_2_DenormalizeOut
								.put(row8.dirname,
										denormalize_result_tDenormalize_2_DenormalizeOut);
					}

					tos_count_tDenormalize_2_DenormalizeOut++;

					/**
					 * [tDenormalize_2_DenormalizeOut main ] stop
					 */

					/**
					 * [tBufferInput_1 end ] start
					 */

					currentComponent = "tBufferInput_1";

					nb_line_tBufferInput_1++;
				}
				globalMap.put("tBufferInput_1_NB_LINE", nb_line_tBufferInput_1);

				ok_Hash.put("tBufferInput_1", true);
				end_Hash.put("tBufferInput_1", System.currentTimeMillis());

				/**
				 * [tBufferInput_1 end ] stop
				 */

				/**
				 * [tDenormalize_2_DenormalizeOut end ] start
				 */

				currentVirtualComponent = "tDenormalize_2";

				currentComponent = "tDenormalize_2_DenormalizeOut";

				java.util.List<OnRowsEndStructtDenormalize_2> result_list_tDenormalize_2_DenormalizeOut = new java.util.ArrayList<OnRowsEndStructtDenormalize_2>();
				if (denormalize_result_tDenormalize_2_DenormalizeOut != null) {
					// generate result begin
					java.util.Iterator<String> dirname_iterator_tDenormalize_2_DenormalizeOut = hash_dirname_tDenormalize_2_DenormalizeOut
							.keySet().iterator();

					while (dirname_iterator_tDenormalize_2_DenormalizeOut
							.hasNext()) {

						String key_dirname_tDenormalize_2_DenormalizeOut = dirname_iterator_tDenormalize_2_DenormalizeOut
								.next();

						denormalize_result_tDenormalize_2_DenormalizeOut = hash_dirname_tDenormalize_2_DenormalizeOut
								.get(key_dirname_tDenormalize_2_DenormalizeOut);

						OnRowsEndStructtDenormalize_2 denormalize_row_tDenormalize_2_DenormalizeOut = new OnRowsEndStructtDenormalize_2();

						denormalize_row_tDenormalize_2_DenormalizeOut.dirname = key_dirname_tDenormalize_2_DenormalizeOut;
						denormalize_row_tDenormalize_2_DenormalizeOut.basename = denormalize_result_tDenormalize_2_DenormalizeOut.basename
								.toString();

						// in the deepest end

						result_list_tDenormalize_2_DenormalizeOut
								.add(denormalize_row_tDenormalize_2_DenormalizeOut);

					}

				}
				// generate result end
				globalMap.put("tDenormalize_2",
						result_list_tDenormalize_2_DenormalizeOut);
				globalMap.put("tDenormalize_2_DenormalizeOut_NB_LINE",
						result_list_tDenormalize_2_DenormalizeOut.size());
				log.info("tDenormalize_2_DenormalizeOut - Generated records count: "
						+ result_list_tDenormalize_2_DenormalizeOut.size()
						+ " .");

				if (log.isInfoEnabled())
					log.info("tDenormalize_2_DenormalizeOut - " + "Done.");

				ok_Hash.put("tDenormalize_2_DenormalizeOut", true);
				end_Hash.put("tDenormalize_2_DenormalizeOut",
						System.currentTimeMillis());

				/**
				 * [tDenormalize_2_DenormalizeOut end ] stop
				 */

				/**
				 * [tJavaRow_3 begin ] start
				 */

				ok_Hash.put("tJavaRow_3", false);
				start_Hash.put("tJavaRow_3", System.currentTimeMillis());

				currentComponent = "tJavaRow_3";

				int tos_count_tJavaRow_3 = 0;

				int nb_line_tJavaRow_3 = 0;

				/**
				 * [tJavaRow_3 begin ] stop
				 */

				/**
				 * [tDenormalize_2_ArrayIn begin ] start
				 */

				ok_Hash.put("tDenormalize_2_ArrayIn", false);
				start_Hash.put("tDenormalize_2_ArrayIn",
						System.currentTimeMillis());

				currentVirtualComponent = "tDenormalize_2";

				currentComponent = "tDenormalize_2_ArrayIn";

				int tos_count_tDenormalize_2_ArrayIn = 0;

				int nb_line_tDenormalize_2_ArrayIn = 0;
				java.util.List<OnRowsEndStructtDenormalize_2> list_tDenormalize_2_ArrayIn = (java.util.List<OnRowsEndStructtDenormalize_2>) globalMap
						.get("tDenormalize_2");
				if (list_tDenormalize_2_ArrayIn == null) {
					list_tDenormalize_2_ArrayIn = new java.util.ArrayList<OnRowsEndStructtDenormalize_2>();
				}
				for (OnRowsEndStructtDenormalize_2 row_tDenormalize_2_ArrayIn : list_tDenormalize_2_ArrayIn) {

					row7.dirname = row_tDenormalize_2_ArrayIn.dirname;

					row7.basename = row_tDenormalize_2_ArrayIn.basename;

					/**
					 * [tDenormalize_2_ArrayIn begin ] stop
					 */

					/**
					 * [tDenormalize_2_ArrayIn main ] start
					 */

					currentVirtualComponent = "tDenormalize_2";

					currentComponent = "tDenormalize_2_ArrayIn";

					tos_count_tDenormalize_2_ArrayIn++;

					/**
					 * [tDenormalize_2_ArrayIn main ] stop
					 */

					/**
					 * [tJavaRow_3 main ] start
					 */

					currentComponent = "tJavaRow_3";

					if (log.isTraceEnabled()) {
						log.trace("row7 - "
								+ (row7 == null ? "" : row7.toLogString()));
					}

					// code sample:
					//
					// multiply by 2 the row identifier
					// output_row.id = row7.id * 2;
					//
					// lowercase the name
					// output_row.name = row7.name.toLowerCase();

					context.ArchiveFileList = row7.basename;
					context.ArchiveFilePath = row7.dirname;
					context.ArchiveFileName = "_tempArchive_" + context.SeqNo
							+ "_" + TalendDate.getDate("yyyMMdd-HHmmss")
							+ ".gz";

					// System.out.println(context.ArchiveFileName);
					// System.out.println(context.ArchiveFilePath);
					// System.out.println(context.ArchiveFileList);

					nb_line_tJavaRow_3++;

					tos_count_tJavaRow_3++;

					/**
					 * [tJavaRow_3 main ] stop
					 */

					/**
					 * [tDenormalize_2_ArrayIn end ] start
					 */

					currentVirtualComponent = "tDenormalize_2";

					currentComponent = "tDenormalize_2_ArrayIn";

					nb_line_tDenormalize_2_ArrayIn++;
				}
				globalMap.put("tDenormalize_2_ArrayIn_NB_LINE",
						nb_line_tDenormalize_2_ArrayIn);

				ok_Hash.put("tDenormalize_2_ArrayIn", true);
				end_Hash.put("tDenormalize_2_ArrayIn",
						System.currentTimeMillis());

				/**
				 * [tDenormalize_2_ArrayIn end ] stop
				 */

				/**
				 * [tJavaRow_3 end ] start
				 */

				currentComponent = "tJavaRow_3";

				globalMap.put("tJavaRow_3_NB_LINE", nb_line_tJavaRow_3);

				ok_Hash.put("tJavaRow_3", true);
				end_Hash.put("tJavaRow_3", System.currentTimeMillis());

				if (((Integer) globalMap.get("tJavaRow_3_NB_LINE")) > 0) {

					tJava_2Process(globalMap);
				}

				/**
				 * [tJavaRow_3 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			// free memory for "tDenormalize_2_ArrayIn"
			globalMap.remove("tDenormalize_2");

			try {

				/**
				 * [tBufferInput_1 finally ] start
				 */

				currentComponent = "tBufferInput_1";

				/**
				 * [tBufferInput_1 finally ] stop
				 */

				/**
				 * [tDenormalize_2_DenormalizeOut finally ] start
				 */

				currentVirtualComponent = "tDenormalize_2";

				currentComponent = "tDenormalize_2_DenormalizeOut";

				/**
				 * [tDenormalize_2_DenormalizeOut finally ] stop
				 */

				/**
				 * [tDenormalize_2_ArrayIn finally ] start
				 */

				currentVirtualComponent = "tDenormalize_2";

				currentComponent = "tDenormalize_2_ArrayIn";

				/**
				 * [tDenormalize_2_ArrayIn finally ] stop
				 */

				/**
				 * [tJavaRow_3 finally ] start
				 */

				currentComponent = "tJavaRow_3";

				/**
				 * [tJavaRow_3 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tBufferInput_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_2Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_2 begin ] start
				 */

				ok_Hash.put("tJava_2", false);
				start_Hash.put("tJava_2", System.currentTimeMillis());

				currentComponent = "tJava_2";

				int tos_count_tJava_2 = 0;

				System.out.println(" ");
				System.out.println("Archive File Name: "
						+ context.ArchiveFilePath + "/"
						+ context.ArchiveFileName);
				System.out.println(" ");
				System.out.println("List of Files Archived:");

				/**
				 * [tJava_2 begin ] stop
				 */

				/**
				 * [tJava_2 main ] start
				 */

				currentComponent = "tJava_2";

				tos_count_tJava_2++;

				/**
				 * [tJava_2 main ] stop
				 */

				/**
				 * [tJava_2 end ] start
				 */

				currentComponent = "tJava_2";

				ok_Hash.put("tJava_2", true);
				end_Hash.put("tJava_2", System.currentTimeMillis());

				tSystem_3Process(globalMap);

				/**
				 * [tJava_2 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_2 finally ] start
				 */

				currentComponent = "tJava_2";

				/**
				 * [tJava_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}

	public void tSystem_3Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tSystem_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tSystem_3 begin ] start
				 */

				ok_Hash.put("tSystem_3", false);
				start_Hash.put("tSystem_3", System.currentTimeMillis());

				currentComponent = "tSystem_3";

				int tos_count_tSystem_3 = 0;

				if (log.isInfoEnabled())
					log.info("tSystem_3 - " + "Start to work.");
				StringBuilder log4jParamters_tSystem_3 = new StringBuilder();
				log4jParamters_tSystem_3.append("Parameters:");
				log4jParamters_tSystem_3.append("ROOTDIR" + " = " + "false");
				log4jParamters_tSystem_3.append(" | ");
				log4jParamters_tSystem_3.append("USE_SINGLE_COMMAND" + " = "
						+ "false");
				log4jParamters_tSystem_3.append(" | ");
				log4jParamters_tSystem_3.append("USE_ARRAY_COMMAND" + " = "
						+ "true");
				log4jParamters_tSystem_3.append(" | ");
				log4jParamters_tSystem_3
						.append("ARRAY_COMMAND"
								+ " = "
								+ "[{VALUE="
								+ ("\"/bin/bash\"")
								+ "}, {VALUE="
								+ ("\"-c\"")
								+ "}, {VALUE="
								+ ("\"cd \"+context.ArchiveFilePath+\"; tar --remove-files -cvf \"+context.ArchiveFileName+\" \"+context.ArchiveFileList")
								+ "}]");
				log4jParamters_tSystem_3.append(" | ");
				log4jParamters_tSystem_3.append("OUTPUT" + " = "
						+ "OUTPUT_TO_CONSOLE");
				log4jParamters_tSystem_3.append(" | ");
				log4jParamters_tSystem_3.append("ERROROUTPUT" + " = "
						+ "OUTPUT_TO_CONSOLE");
				log4jParamters_tSystem_3.append(" | ");
				log4jParamters_tSystem_3.append("PARAMS" + " = " + "[]");
				log4jParamters_tSystem_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tSystem_3 - " + log4jParamters_tSystem_3);

				String commandArrayForLog_tSystem_3 = "";

				String[] command_tSystem_3 = new String[3];

				command_tSystem_3[0] = "/bin/bash";

				if (("/bin/bash").contains(" "))
					commandArrayForLog_tSystem_3 += "\"" + "/bin/bash" + "\" ";
				else
					commandArrayForLog_tSystem_3 += "/bin/bash" + " ";

				command_tSystem_3[1] = "-c";

				if (("-c").contains(" "))
					commandArrayForLog_tSystem_3 += "\"" + "-c" + "\" ";
				else
					commandArrayForLog_tSystem_3 += "-c" + " ";

				command_tSystem_3[2] = "cd " + context.ArchiveFilePath
						+ "; tar --remove-files -cvf "
						+ context.ArchiveFileName + " "
						+ context.ArchiveFileList;

				if (("cd " + context.ArchiveFilePath
						+ "; tar --remove-files -cvf "
						+ context.ArchiveFileName + " " + context.ArchiveFileList)
						.contains(" "))
					commandArrayForLog_tSystem_3 += "\"" + "cd "
							+ context.ArchiveFilePath
							+ "; tar --remove-files -cvf "
							+ context.ArchiveFileName + " "
							+ context.ArchiveFileList + "\" ";
				else
					commandArrayForLog_tSystem_3 += "cd "
							+ context.ArchiveFilePath
							+ "; tar --remove-files -cvf "
							+ context.ArchiveFileName + " "
							+ context.ArchiveFileList + " ";

				Runtime runtime_tSystem_3 = Runtime.getRuntime();

				String[] env_tSystem_3 = null;
				java.util.Map<String, String> envMap_tSystem_3 = System
						.getenv();
				java.util.Map<String, String> envMapClone_tSystem_3 = new java.util.HashMap();
				envMapClone_tSystem_3.putAll(envMap_tSystem_3);

				log.info("tSystem_3 - Setting the parameters.");
				final Process ps_tSystem_3 = runtime_tSystem_3.exec(
						command_tSystem_3, env_tSystem_3);

				globalMap.remove("tSystem_3_OUTPUT");
				globalMap.remove("tSystem_3_ERROROUTPUT");

				Thread normal_tSystem_3 = new Thread() {
					public void run() {
						try {
							java.io.BufferedReader reader = new java.io.BufferedReader(
									new java.io.InputStreamReader(
											ps_tSystem_3.getInputStream()));
							String line = "";
							try {
								while ((line = reader.readLine()) != null) {

									log.debug("tSystem_3 - Sending the standard output to the console.");

									System.out.println(line);
								}
							} finally {
								reader.close();
							}
						} catch (java.io.IOException ioe) {

							log.error("tSystem_3 - " + ioe.getMessage());

							ioe.printStackTrace();
						}
					}
				};
				log.info("tSystem_3 - Executing the command.");
				log.info("tSystem_3 - Command to execute: '"
						+ commandArrayForLog_tSystem_3 + "'.");
				normal_tSystem_3.start();
				log.info("tSystem_3 - The command has been executed successfully.");

				Thread error_tSystem_3 = new Thread() {
					public void run() {
						try {
							java.io.BufferedReader reader = new java.io.BufferedReader(
									new java.io.InputStreamReader(
											ps_tSystem_3.getErrorStream()));
							String line = "";
							try {
								while ((line = reader.readLine()) != null) {

									log.debug("tSystem_3 - Sending the error output to the console.");

									System.err.println(line);
								}
							} finally {
								reader.close();
							}
						} catch (java.io.IOException ioe) {

							log.error("tSystem_3 - " + ioe.getMessage());

							ioe.printStackTrace();
						}
					}
				};
				error_tSystem_3.start();
				if (ps_tSystem_3.getOutputStream() != null) {
					ps_tSystem_3.getOutputStream().close();
				}
				ps_tSystem_3.waitFor();
				normal_tSystem_3.join(10000);
				error_tSystem_3.join(10000);

				/**
				 * [tSystem_3 begin ] stop
				 */

				/**
				 * [tSystem_3 main ] start
				 */

				currentComponent = "tSystem_3";

				tos_count_tSystem_3++;

				/**
				 * [tSystem_3 main ] stop
				 */

				/**
				 * [tSystem_3 end ] start
				 */

				currentComponent = "tSystem_3";

				globalMap.put("tSystem_3_EXIT_VALUE", ps_tSystem_3.exitValue());

				if (log.isInfoEnabled())
					log.info("tSystem_3 - " + "Done.");

				ok_Hash.put("tSystem_3", true);
				end_Hash.put("tSystem_3", System.currentTimeMillis());

				/**
				 * [tSystem_3 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tSystem_3 finally ] start
				 */

				currentComponent = "tSystem_3";

				/**
				 * [tSystem_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tSystem_3_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private java.util.Properties context_param = new java.util.Properties();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final PurgeUtility PurgeUtilityClass = new PurgeUtility();

		int exitCode = PurgeUtilityClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'PurgeUtility' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = (String[][]) globalBuffer
				.toArray(new String[globalBuffer.size()][]);

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		hastBufferOutput = true;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (!"".equals(log4jLevel)) {
			if ("trace".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.OFF);
			}
			org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
		}
		log.info("TalendJob: 'PurgeUtility' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		try {
			// call job/subjob with an existing context, like:
			// --context=production. if without this parameter, there will use
			// the default context instead.
			java.io.InputStream inContext = PurgeUtility.class.getClassLoader()
					.getResourceAsStream(
							"local_project/purgeutility_1_1/contexts/"
									+ contextStr + ".properties");
			if (isDefaultContext && inContext == null) {

			} else {
				if (inContext != null) {
					// defaultProps is in order to keep the original context
					// value
					defaultProps.load(inContext);
					inContext.close();
					context = new ContextProperties(defaultProps);
				} else {
					// print info and job continue to run, for case:
					// context_param is not empty.
					System.err.println("Could not find the context "
							+ contextStr);
				}
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
			}
			context.FolderPath = (String) context.getProperty("FolderPath");
			context.FilePattern = (String) context.getProperty("FilePattern");
			try {
				context.PurgeDayOld = routines.system.ParserUtils
						.parseTo_Integer(context.getProperty("PurgeDayOld"));
			} catch (NumberFormatException e) {
				context.PurgeDayOld = null;
			}
			context.DelFilePath = (String) context.getProperty("DelFilePath");
			try {
				context.ArchiveDayOld = routines.system.ParserUtils
						.parseTo_Integer(context.getProperty("ArchiveDayOld"));
			} catch (NumberFormatException e) {
				context.ArchiveDayOld = null;
			}
			context.ArchiveFileList = (String) context
					.getProperty("ArchiveFileList");
			context.ArchiveFilePath = (String) context
					.getProperty("ArchiveFilePath");
			context.ArchiveFileName = (String) context
					.getProperty("ArchiveFileName");
			try {
				context.SeqNo = routines.system.ParserUtils
						.parseTo_Integer(context.getProperty("SeqNo"));
			} catch (NumberFormatException e) {
				context.SeqNo = null;
			}
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("FolderPath")) {
				context.FolderPath = (String) parentContextMap
						.get("FolderPath");
			}
			if (parentContextMap.containsKey("FilePattern")) {
				context.FilePattern = (String) parentContextMap
						.get("FilePattern");
			}
			if (parentContextMap.containsKey("PurgeDayOld")) {
				context.PurgeDayOld = (Integer) parentContextMap
						.get("PurgeDayOld");
			}
			if (parentContextMap.containsKey("DelFilePath")) {
				context.DelFilePath = (String) parentContextMap
						.get("DelFilePath");
			}
			if (parentContextMap.containsKey("ArchiveDayOld")) {
				context.ArchiveDayOld = (Integer) parentContextMap
						.get("ArchiveDayOld");
			}
			if (parentContextMap.containsKey("ArchiveFileList")) {
				context.ArchiveFileList = (String) parentContextMap
						.get("ArchiveFileList");
			}
			if (parentContextMap.containsKey("ArchiveFilePath")) {
				context.ArchiveFilePath = (String) parentContextMap
						.get("ArchiveFilePath");
			}
			if (parentContextMap.containsKey("ArchiveFileName")) {
				context.ArchiveFileName = (String) parentContextMap
						.get("ArchiveFileName");
			}
			if (parentContextMap.containsKey("SeqNo")) {
				context.SeqNo = (Integer) parentContextMap.get("SeqNo");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "",
				resumeUtil.convertToJsonText(context, parametersToEncrypt));

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileList_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileList_1) {
			globalMap.put("tFileList_1_SUBPROCESS_STATE", -1);

			e_tFileList_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : PurgeUtility");
		}

		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "" + returnCode, "",
				"", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		}

	}

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" },
			{ "\\'", "\'" }, { "\\r", "\r" }, { "\\f", "\f" }, { "\\b", "\b" },
			{ "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex,
							index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left
			// into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 111779 characters generated by Talend Data Management Platform on the August
 * 30, 2016 11:21:15 AM EDT
 ************************************************************************************************/
