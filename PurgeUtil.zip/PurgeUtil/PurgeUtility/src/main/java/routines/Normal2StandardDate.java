package routines;
import java.util.Calendar;
import java.util.Date;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import routines.StringHandler;
public class Normal2StandardDate {

	public static Date ConvertToSmallDateTime(String stringDate, String pattern)
    {
		
            Date resultDate=null;
            if (stringDate!=null)
            {
            	Date d=TalendDate.parseDate(pattern, stringDate);
                if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
    			{
                    resultDate= TalendDate.parseDate(pattern, stringDate);
    			}
            }
            return resultDate;
    }
	
	public static String getCDate(String tdate,String dtype,int vCenturay ) throws ParseException
	{   
	    if (tdate!=null )/* Checking Null */
		{	    
	    	tdate = tdate.trim();
	    	if(dtype.equalsIgnoreCase("C"))
	    	{
	    	int b=Integer.parseInt(tdate);
	    	int Y=(b/10000)+1900;
	    	if(vCenturay==20 && Y<1931)
	    	{
	    		Y=Y+100;
	    	}
	    	int M=(b%10000)/100;
	    	M=M>0?M:M+1;
	    	int D=b%100;
	    	D=D>0?D:D+1;
	    	tdate= ((M<10)?"0"+new BigDecimal(M).toString():new BigDecimal(M).toString())+"-"+
	    	((D<10)?"0"+new BigDecimal(D).toString():new BigDecimal(D).toString())+"-"+new BigDecimal(Y).toString();
	       	if(TalendDate.isDate(StringHandling.TRIM(tdate),"MM-dd-yyyy") && !(tdate.equals("01-01-1900")))
	    	{
	       		return tdate;
	        }
	       	else
	       	{
				return(null);
			}
	    	}
	       	else
	    	{
				return(null);
			}
		}
	    else
	    {
	    	return null;
	    }
	    	
	}

	@SuppressWarnings("deprecation")
	public static String getDate(String tdate,String dtype ) throws ParseException
	{   
	    dtype=dtype.trim();
		if (tdate!=null )/* Checking Null */
		{
	    	if( tdate.trim().length()<3 || tdate.equals("0"))
	    	{
	    		return(null);
	    	}
	    	else
	    	{
	    		tdate=routines.StringHandler.RemoveSpecialchars(tdate);
	    		tdate=tdate.replaceAll("[/.]","-");
	    		dtype=dtype.replaceAll("[/.]","-");
	    		if(tdate.length()>dtype.length() && !(dtype.equalsIgnoreCase("J") || dtype.equalsIgnoreCase("C")))

	    		{
	    		//System.out.println("More length");
	    		tdate=tdate.substring(0,dtype.length());
	    		//System.out.println(tdate);
	    		}
	    	tdate=tdate.trim();
		if (dtype.equalsIgnoreCase("J")) /* 1) Begin Julian conversion */
		{	
			int yr= Integer.parseInt(tdate)/ 1000+1900;
            int dy= Integer.parseInt(tdate)% 1000;
			Date d=TalendDate.parseDate("yyyy-MM-dd",yr+"-01-01");
			SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(d); // Now use today date.
			c.add(Calendar.DATE, dy-1); // Adding 5 days
			String resultdate = sdf.format(c.getTime());
			if(dy<=365)
			{
				return resultdate;
			}
			else if(dy<=366 && (yr%4==0))
			{
				if(yr%100!=0 && yr%400!=0)
				  {	
					return resultdate;
				  }
				else if(yr%100==0 && yr%400==0)
				  {
					return resultdate;
				  }
				else
				{
					return null;
				}
		    }
			else if(dy>365)
			{
			 return null;
			}
			else
			return null;
	    }/* End Julian Date Conversion  */

		else if(dtype.equalsIgnoreCase("C"))  /*  2) Begin CYYMMDD Conversion  */
		{
			
			int b=Integer.parseInt(tdate);
	    	int Y=(b/10000)+1900;
	    	int M=(b%10000)/100;
	    	M=M>0?M:M+1;
	    	int D=b%100;
	    	D=D>0?D:D+1;
	    	tdate= ((M<10)?"0"+new BigDecimal(M).toString():new BigDecimal(M).toString())+"-"+
	    	((D<10)?"0"+new BigDecimal(D).toString():new BigDecimal(D).toString())+"-"+new BigDecimal(Y).toString();
	       	if(TalendDate.isDate(StringHandling.TRIM(tdate),"MM-dd-yyyy") && !(tdate.equals("01-01-1900")))
	    	{
	       		Date d=TalendDate.parseDate("MM-dd-yyyy",tdate);
	    		if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
			return (tdate);
			}
			else
			{
				return(null);
			}
	    	}
	       	else
	    	{
				return(null);
			}	
	        }  /*  End CYYMMDD Conversion  */
		
		
		else if(dtype.equalsIgnoreCase("YYYYMMDD") && (TalendDate.isDate(StringHandling.TRIM(tdate),"yyyyMMdd")))  /*  3) Begin YYYYMMDD Conversion  */
		{
			
			Date d=TalendDate.parseDate("yyyyMMdd",tdate);
			if(d.after(TalendDate.parseDate("MMddyyyy","12311899")) && d.before(TalendDate.parseDate("MMddyyyy","06072079")))
			{
				tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
				+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
				+"-"+new BigDecimal(d.getYear()+1900).toString();
			return (tdate);
			}
			else
			{
				return(null);
			}
		}   /*  End YYYYMMDD Conversion  */
		else if(dtype.equalsIgnoreCase("YYYY-MM-DD") && (TalendDate.isDate(StringHandling.TRIM(tdate),"yyyy-MM-dd")))  
			/*  4) Begin  YYYY/MM/DD, YYYY.MM.DD and YYYY-MM-DD Conversion  */
		{
			Date d=TalendDate.parseDate("yyyy-MM-dd",tdate);
			if(d.after(TalendDate.parseDate("MMddyyyy","12311899")) && d.before(TalendDate.parseDate("MMddyyyy","06072079")))
			{
				tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
				+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
				+"-"+new BigDecimal(d.getYear()+1900).toString();
			return (tdate);
			}
			else
			{
				return(null);
			}
		}   /*  End  YYYY/MM/DD, YYYY.MM.DD and YYYY-MM-DD Conversion  */
		else if(dtype.equalsIgnoreCase("MMDDYYYY") && TalendDate.isDate(StringHandling.TRIM(tdate),"MMddyyyy"))  /*  5) Begin MMDDYYYY Conversion  */
		{
			Date d=TalendDate.parseDate("MMddyyyy",tdate);
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		} /*  End MMDDYYYY Conversion  */
		else if(dtype.equalsIgnoreCase("MM-DD-YYYY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"MM-dd-yyyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"M-d-yyyy") 
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"MM-d-yyyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"M-dd-yyyy")))  /*  6) Begin MM/DD/YYYY, MM.DD.YYYY and MM-DD-YYYY Conversion  */
		{
			
			Date d=TalendDate.parseDate("MM-dd-yyyy",tdate);
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		} /*  End MM/DD/YYYY, MM.DD.YYYY and MM-DD-YYYY Conversion  */
		else if(dtype.equalsIgnoreCase("DDMMMYYYY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"ddMMMyyyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"dMMMyyyy")))   /* 7) Begin DDMMMYYYY Conversion  */
		{
			Date d=TalendDate.parseDate("ddMMMyyyy",tdate);
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}   /*  End DDMMMYYYY Conversion  */
		else if(dtype.equalsIgnoreCase("DD-MMM-YYYY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"dd-MMM-yyyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"d-MMM-yyyy")))   /* 8) Begin DD/MMM/YYYY, DD.MMM.YYYY and DD-MMM-YYYY Conversion  */
		{
			Date d=TalendDate.parseDate("dd-MMM-yyyy",tdate);
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}   /*  End DD/MMM/YYYY, DD.MMM.YYYY and DD-MMM-YYYY Conversion  */
		else if (dtype.equalsIgnoreCase("DDMMMYY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"ddMMMyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"dMMMyy"))) /* 9) Begin DD-MMM-YY, DD/MMM/YY, DD.MMM.YY and DDMMMYY Conversion  */
		{
			if(tdate.length()<dtype.length())
			{
				tdate="0"+tdate;
			}
			Date d=TalendDate.parseDate("ddMMMyy",tdate);
			int addyear=0;
			if(d.getYear()+1900>1932 && d.getYear()+1900<1961)
			{
			addyear=100;
			}
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():
							"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():
								"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900+addyear).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}  /*  End DD-MMM-YY, DD/MMM/YY, DD.MMM.YY and DDMMMYY Conversion  */
		else if (dtype.equalsIgnoreCase("DD-MMM-YY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"dd-MMM-yy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"d-MMM-yy"))) /* 10) Begin DD/MMM/YY, DD.MMM.YY and DD-MMM-YY Conversion  */
		{
			if(tdate.length()<dtype.length())
			{
				tdate="0"+tdate;
			}
			Date d=TalendDate.parseDate("dd-MMM-yy",tdate);
			int addyear=0;
			if(d.getYear()+1900>1932 && d.getYear()+1900<1961)
			{
			addyear=100;
			}
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():
							"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():
								"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900+addyear).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}  /*  End DD/MMM/YY, DD.MMM.YY and DD-MMM-YY Conversion  */		
		else if(dtype.equalsIgnoreCase("MMDDYY") && TalendDate.isDate(StringHandling.TRIM(tdate),"MMddyy"))
			/* 11) Begin MMDDYY Conversion */
		{
			Date d=TalendDate.parseDate("dd-MMM-yy",tdate);
			int addyear=0;
			if(d.getYear()+1900>1932 && d.getYear()+1900<1961)
			{
			addyear=100;
			}
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900+addyear).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}/* End MMDDYY Conversion */
		else if(dtype.equalsIgnoreCase("MM-DD-YY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"MM-dd-yy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"M-d-yy") 
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"MM-d-yy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"M-dd-yy")))/* 12) Begin MM/DD/YY, MM.DD.YY and MM-DD-YY Conversion */
		{
			int addyear=0;
			Date d=TalendDate.parseDate("MM-dd-yy",tdate);
			if(d.getYear()+1900>1932 && d.getYear()+1900<1961)
			{
			addyear=100;
			}
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900+addyear).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}/* End MM/DD/YY, MM.DD.YY and MM-DD-YY Conversion */
		else if(dtype.equalsIgnoreCase("YYMMDD") && TalendDate.isDate(StringHandling.TRIM(tdate),"yyMMdd"))
		/* 13) Begin YYMMDD Conversion */
		{
			Date d=TalendDate.parseDate("yyMMdd",tdate);
			int addyear=0;
			if(d.getYear()+1900>1932 && d.getYear()+1900<1961)
			{
			addyear=100;
			}
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900+addyear).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}/* End YYMMDD Conversion */
		else if(dtype.equalsIgnoreCase("YY-MM-DD") && (TalendDate.isDate(StringHandling.TRIM(tdate),"yy-MM-dd")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"yy-M-d") 
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"yy-MM-d")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"yy-M-dd")))/* 14) Begin YY/MM/DD, YY.MM.DD and YY-MM-DD Conversion */
		{
			Date d=TalendDate.parseDate("yy-MM-dd",tdate);
			int addyear=0;
			if(d.getYear()+1900>1932 && d.getYear()+1900<1961)
			{
			addyear=100;
			}
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900+addyear).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}/* End YY/MM/DD, YY.MM.DD and YY-MM-DD Conversion */
		else if(dtype.equalsIgnoreCase("DDMMYYYY") && TalendDate.isDate(StringHandling.TRIM(tdate),"ddMMyyyy"))
		/* 15) Begin DDMMYYYY Conversion */
		{
			Date d=TalendDate.parseDate("ddMMyyyy",tdate);
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}/* End DDMMYYYY Conversion */
		else if(dtype.equalsIgnoreCase("DD-MM-YYYY") && (TalendDate.isDate(StringHandling.TRIM(tdate),"dd-MM-yyyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"d-MM-yyyy") 
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"dd-M-yyyy")
				|| TalendDate.isDate(StringHandling.TRIM(tdate),"d-M-yyyy")))/* 16) Begin DD/MM/YYYY, DD.MM.YYYY and DD-MM-YYYY Conversion */
		{
			Date d=TalendDate.parseDate("dd-MM-yyyy",tdate);
			if(d.after(TalendDate.parseDate("MM-dd-yyyy","12-31-1899")) && d.before(TalendDate.parseDate("MM-dd-yyyy","06-07-2079")))
			{
						tdate= (d.getMonth()+1>9?new BigDecimal(d.getMonth()+1).toString():"0"+new BigDecimal(d.getMonth()+1).toString())
							+"-"+(d.getDate()>9?new BigDecimal(d.getDate()).toString():"0"+new BigDecimal(d.getDate()).toString())
							+"-"+new BigDecimal(d.getYear()+1900).toString();
						return(tdate);
			}
			else
			{
				return (null);
			}
		}/* End DD/MM/YYYY, DD.MM.YYYY and DD-MM-YYYY Conversion */
		else 
		{
			return (null);
		}
		}
			
		}
		
		else 
		{
			return (null);
		}
			
	}
	public static Date GetDateFromString(String tdate,String dFormat,String dRequiredFormat)throws ParseException
	{
		String result=null;
		Date d=null;
		if(tdate!=null && dFormat!=null)  
		{
			if(!dFormat.isEmpty() && tdate!="" && tdate.length()>2)
			{
			//System.out.println(tdate);
			SimpleDateFormat f = new SimpleDateFormat(dFormat);
			d= f.parse(tdate);
			//dRequiredFormat
			if(dRequiredFormat!=null && dRequiredFormat!="")
			{
				f = new SimpleDateFormat(dRequiredFormat);
				result=f.format(d);
			}
			else 
			{
				f = new SimpleDateFormat("yyyy-MM-dd");
				result=f.format(d);
			}//
			}//second if
		}//first if
		return d;
	}	
}