package routines;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class PRGHASH {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     * @throws IOException 
     */
	public static String vFileTypebyHASH="File";
	public static boolean vFilecompressed  =false;
	public static boolean vFileIncriptd  =false;
	public static String vQuarterValue_2digit ="00";
	//public static String vOldExtension ="";
	//public static String vNewExtension ="";
	
	
   
 public static String GetFileType(String pFileName) throws IOException {
        
    	if (pFileName != null) {
    		//System.out.println(pFileName);
        	java.io.FileInputStream fis = null;
			try {
				fis = new java.io.FileInputStream(pFileName);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	//byte[] b = new byte[10];
        	int i = 0;
        	StringBuffer sb = new StringBuffer();
        	try {
				while ((i = fis.read()) !=-1) {
				 if (i != 10 && sb.length()<=50)
				 {
					sb.append(String.format("%02X ", i));
					
					
				 }
				 if (sb.length()>=50)
				 {
					 break;
					  
				 }
				 	//fis.close();
				 	//System.out.println(sb.toString());
				 	
				  }
				 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				 fis.close();
			}
            fis.close();
            String hashValue = sb.toString();
            //System.out.println(sb.toString());
            //XLSX
            if (hashValue.contains("50 4B 03 04 14 00 06 00 08 00 00 00 21 00 41 37 82")){
            	vFileTypebyHASH="File";
            	vFilecompressed=false;
            }
            else if (hashValue.contains("50 4B 03 04") 
            		&& !hashValue.contains("50 4B 03 04 14 00 06 00 08 00 00 00 21 00 41 37 82")){
            	vFileTypebyHASH="PKZIP";
            	vFilecompressed=true;
            	//System.out.println(sb.toString());
            }
            else if (hashValue.startsWith("1F 9D 90") 
            		|| hashValue.startsWith("FF FE 1F") 
            		|| hashValue.startsWith("1F 8B 08"))
            {
            	vFileTypebyHASH="GZ,TGZ,GZIP";
            	vFilecompressed=true;
            }
            else if (hashValue.contains("75 73 74 61 72")){//||hashValue.contains("1F A0")||hashValue.contains("1F 9D")){
            	vFileTypebyHASH="TAR";
            	vFilecompressed=true;
            }
        	else if (hashValue.contains("52 61 72 21 1A 07 00")){
        		vFileTypebyHASH="WinRAR";
        		vFilecompressed=true;
        	}
			else if (hashValue.contains("37 7A BC AF 27 1C")){
				vFileTypebyHASH="7-Zip";
				vFilecompressed=true;
			}
			else if (hashValue.contains("FD FF FF FF nn 02")||hashValue.contains("FD FF FF FF nn 00")||hashValue.contains("FD FF FF FF 20 00 00 00")){
				vFileTypebyHASH="File";
				vFilecompressed=true;
			}
			else if (hashValue.contains("85 02 0E 03 F9 25 33 E2")
					||hashValue.contains("85 02 0D 03 F9 25 33 E2 AE DE 20")
					||hashValue.contains("2D 2D 2D 2D 2D 42 45 47 49 4E 20")
					||hashValue.contains("85 02 0C 03 F9 25 33 E2")
					||hashValue.contains("A8 03 50 47 50 C1 C1")
					||hashValue.contains("A8 03 50 47 50 C1 C1 4E 03 F9 25")){
				vFileTypebyHASH="PGP";
				vFilecompressed=false;
				vFileIncriptd=true;
			}
			else {vFileTypebyHASH ="File"; 
			vFilecompressed=false;}
        }
    	//System.out.println(vFileTypebyHASH);
    	return vFileTypebyHASH;
        
    }

 // Implement function to create a table name as per there load frequency
 public static String GetTableName(Long pDateString,String pLoadFrequency){
	 String vTableNameRe ="";
	 if (!pLoadFrequency.isEmpty()){
		Date inDate = new java.util.Date(pDateString);  //TalendDate.parseDate("yyyyMMdd", pDateString);
		 if (pLoadFrequency.contains("Daily"))
		 {
			 vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(inDate);
		 }
		 else if (pLoadFrequency.contains("Weekly"))
		 {
			if (!inDate.toString().contains("mon"))//Calendar.MONDAY)
			{
				if (inDate.toString().contains("tue"))//Calendar.TUESDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -1, "dd"));// (, -1, "dd");
				}
				else if (inDate.toString().contains("wed"))//Calendar.WEDNESDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -2, "dd"));
				}
				else if (inDate.toString().contains("thu"))//Calendar.THURSDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -3, "dd"));
				}
				else if (inDate.toString().contains("fri"))//Calendar.FRIDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -4, "dd"));
				}
				else if (inDate.toString().contains("sat"))// Calendar.SATURDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -5, "dd"));
				}
				else if (inDate.toString().contains("sun")) //Calendar.SUNDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -6, "dd"));
				}
				
			   // vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(inDate);
			}
			else {vTableNameRe=new SimpleDateFormat("yyyyMMdd").format(inDate);}
				 
		 }
		 else if (pLoadFrequency.contains("Monthly")){
			 vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
		 }
		 else if (pLoadFrequency.contains("Quarterly")){
			 int month = TalendDate.getPartOfDate("MONTH", inDate);
			 if (month >= Calendar.JANUARY && month <= Calendar.MARCH) 
			 {
				 vQuarterValue_2digit="01";
				 if (month == Calendar.JANUARY) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.FEBRUARY)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.MARCH)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
			 else if (month >= Calendar.APRIL && month <= Calendar.JUNE) 
			 {
				 vQuarterValue_2digit="02";
				 if (month == Calendar.APRIL) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.MAY)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.JUNE)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
			 else if (month >= Calendar.JULY && month <= Calendar.SEPTEMBER)
			 {
				 vQuarterValue_2digit="03";
				 if (month == Calendar.JULY) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.AUGUST)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.SEPTEMBER)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
			 else 
			 {
				 vQuarterValue_2digit="04";
				 if (month == Calendar.OCTOBER) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.NOVEMBER)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.DECEMBER)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
		 }
		 else {
			 vTableNameRe = TalendDate.getDate("yyyyMMdd");
		 }
	 }
	 return vTableNameRe;
 }
//Implement function to create a table name as per there load frequency
 public static String GetTableName(Long pDateString,String pLoadFrequency,String pTableNameRe) throws ParseException{
	 String vTableNameRe ="";
	 if (!pLoadFrequency.isEmpty()){
		Date inDate = new java.util.Date(pDateString);  //TalendDate.parseDate("yyyyMMdd", pDateString);
		 if (pLoadFrequency.contains("Daily"))
		 {
			 vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(inDate);
		 }
		 else if (pLoadFrequency.toLowerCase().contains("weekly"))
		 {
			if (!inDate.toString().toLowerCase().contains("mon"))//Calendar.MONDAY)
			{
				if (inDate.toString().toLowerCase().contains("tue"))//Calendar.TUESDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -1, "dd"));// (, -1, "dd");
				}
				else if (inDate.toString().toLowerCase().contains("wed"))//Calendar.WEDNESDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -2, "dd"));
				}
				else if (inDate.toString().toLowerCase().contains("thu"))//Calendar.THURSDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -3, "dd"));
				}
				else if (inDate.toString().toLowerCase().contains("fri"))//Calendar.FRIDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -4, "dd"));
				}
				else if (inDate.toString().toLowerCase().contains("sat"))// Calendar.SATURDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -5, "dd"));
				}
				else if (inDate.toString().toLowerCase().contains("sun")) //Calendar.SUNDAY)
				{
					vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.addDate(inDate, -6, "dd"));
				}
				
			   // vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(inDate);
			}
			else {vTableNameRe=new SimpleDateFormat("yyyyMMdd").format(inDate);}
				 
		 }
		 else if (pLoadFrequency.contains("Monthly")){
			 
			 vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
		 }
		 else if (pLoadFrequency.contains("Quarterly")){
			 int month = TalendDate.getPartOfDate("MONTH", inDate);
			 if (month >= Calendar.JANUARY && month <= Calendar.MARCH) 
			 {
				 vQuarterValue_2digit="01";
				 if (month == Calendar.JANUARY) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.FEBRUARY)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.MARCH)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
			 else if (month >= Calendar.APRIL && month <= Calendar.JUNE) 
			 {
				 vQuarterValue_2digit="02";
				 if (month == Calendar.APRIL) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.MAY)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.JUNE)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
			 else if (month >= Calendar.JULY && month <= Calendar.SEPTEMBER)
			 {
				 vQuarterValue_2digit="03";
				 if (month == Calendar.JULY) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.AUGUST)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.SEPTEMBER)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
			 else 
			 {
				 vQuarterValue_2digit="04";
				 if (month == Calendar.OCTOBER) vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(inDate));
			     if (month == Calendar.NOVEMBER)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -1, "MM")));
			     if (month == Calendar.DECEMBER)vTableNameRe = new SimpleDateFormat("yyyyMMdd").format(TalendDate.getFirstDayOfMonth(TalendDate.addDate(inDate, -2, "MM")));
			 }
		 }
		 else {
			 vTableNameRe = TalendDate.getDate("yyyyMMdd");
		 }
	 }
	 ///get the table name with date part or date 
	 //******************************************///
	 //                 Start                    //
	 //******************************************//
	 //System.out.println(pTableNameRe.toString());
	 if(!pTableNameRe.contains(",")){
		 /*
	 if (pTableNameRe.toUpperCase().contains("_XX_YR")){	 
		 vTableNameRe = pTableNameRe.toUpperCase().replace("_XX_YR","_"+vQuarterValue_2digit+"_"+vTableNameRe.substring(2, 2));
	 }
	 else if (pTableNameRe.toUpperCase().contains("_XX")&& !pTableNameRe.toUpperCase().contains("_XX_YR")){	 
		 vTableNameRe = pTableNameRe.toUpperCase().replace("_XX","_"+vQuarterValue_2digit);
	 }
	 else if (pTableNameRe.contains("_PXX")){	 
		 vTableNameRe = pTableNameRe.toUpperCase().replace("PXX","P"+vQuarterValue_2digit);
	 }
	 else if (pTableNameRe.toUpperCase().contains("_MMDDYY")){
		 vTableNameRe = pTableNameRe.toUpperCase().replace("MMDDYY", vTableNameRe.substring(4, 2)+vTableNameRe.substring(6, 2)+vTableNameRe.substring(2, 2));
	 }
	 else if (pTableNameRe.toUpperCase().contains("_YYYYMM") && !pTableNameRe.contains("_YYYYMMDD")){
		 vTableNameRe = pTableNameRe.toUpperCase().replace("YYYYMM",vTableNameRe.substring(0, 6));
	 }
	 else if (pTableNameRe.toUpperCase().contains("_YYYYMMDD")){
		 vTableNameRe = pTableNameRe.toUpperCase().replace("YYYYMMDD", vTableNameRe);
	 }
	 */ //System.out.println(vTableNameRe+"^^"+pTableNameRe);
		 vTableNameRe= GetTableNameAfter(vTableNameRe, pTableNameRe);
		 //System.out.println(vTableNameRe);
	 }else {
		 String[] tableNames = pTableNameRe.split(",");
		 StringBuilder sb = new StringBuilder();
		 for (String tableName : tableNames) {
			sb.append(GetTableNameAfter(vTableNameRe, tableName)+",");
		}
		
		 vTableNameRe = sb.toString().substring(0,sb.length()-1);
		 //System.out.println(vTableNameRe);
	 }
	 return vTableNameRe;
 }

 public static String GetDateFor7DigitNumber(String pInputDate){
	 String DateValue = "1900-01-01";
	 if (pInputDate.length()<6) 
		 return DateValue;
	 if (!pInputDate.isEmpty() && isNumeric(pInputDate.trim(),1) && pInputDate!=null){
		 try {
			 int ll = new  Integer (pInputDate) +19000000;
			 DateValue=String.valueOf(ll).toString();
		 }
		 catch (Exception e){
			 e.printStackTrace();
		 }
	 }
	 
	 return DateValue;
 }
 /*
 @SuppressWarnings("deprecation")
public static String GetDateFor7DigitNumber(String pInputDate, boolean pWithinaRange){
	 String DateValue = "1900-01-01";
	 Date DateMinValue = new Date(1753,01,01);
	 Date DateMaxValue= new Date(9999,12,31);
	 
	 if (pInputDate.length()<6) 
		 return DateValue;
	 if (!pInputDate.isEmpty() && isNumeric(pInputDate.trim(),1) && pInputDate!=null){
		 try {
			 int ll = new  Integer (pInputDate) +19000000;
			 DateValue=String.valueOf(ll).toString();
		 }
		 catch (Exception e){
			 e.printStackTrace();
		 }
	 } 
	 if  (pWithinaRange){
		 
	 }
	 return DateValue;
 }*/
public static Boolean isNumeric(String r){
	NumberFormat formater = NumberFormat.getInstance();
	ParsePosition pos = new ParsePosition(0);
	formater.parse(r, pos);
	return r.length()== pos.getIndex();
} 
///get the table name with date part or date 
//******************************************///
//                 Start                    //
//******************************************//
public static String GetTableNameAfter(String pTableNameReDate, String pTableName) throws ParseException{
	//System.out.println(">>"+pTableNameReDate);
	//Date dt = new java.util.Date(Long.valueOf(pTableNameReDate.toString()));
	//System.out.println(new SimpleDateFormat("MMddyyyy").format(dt));
	if (pTableName.toUpperCase().contains("_XX_YR")){	 
		pTableName = pTableName.toUpperCase().replace("_XX_YR","_"+vQuarterValue_2digit+"_"+pTableNameReDate.substring(2, 2));
	 }
	 else if (pTableName.toUpperCase().contains("_XX")&& !pTableName.toUpperCase().contains("_XX_YR")){	 
		 pTableName = pTableName.toUpperCase().replace("_XX","_"+vQuarterValue_2digit);
	 }
	 else if (pTableName.contains("_PXX")){	 
		 pTableName = pTableName.toUpperCase().replace("PXX","P"+vQuarterValue_2digit);
	 }
	 else if (pTableName.toUpperCase().contains("_MMDDYY")&& !pTableName.toUpperCase().contains("_MMDDYYYY")){
		 pTableName = pTableName.toUpperCase().replace("MMDDYY", pTableNameReDate.substring(4, 2)+pTableNameReDate.substring(6, 2)+pTableNameReDate.substring(2, 2));
	 }
	 else if (pTableName.toUpperCase().contains("_MMDDYYYY")){
		 //System.out.println(pTableNameReDate.length());//String.format("MMDDYYYY", dt));
		 pTableName = pTableName.toUpperCase().replace("MMDDYYYY", pTableNameReDate.substring(4, 6)+pTableNameReDate.substring(6, 8)+pTableNameReDate.substring(0, 4));
		 //System.out.println(pTableName);
	 }
	 else if (pTableName.toUpperCase().contains("_YYYYMM") && !pTableName.contains("_YYYYMMDD")){
		 pTableName = pTableName.toUpperCase().replace("YYYYMM",pTableNameReDate.substring(0, 6));
	 }
	 else if (pTableName.toUpperCase().contains("_YYYYMMDD")){
		 pTableName = pTableName.toUpperCase().replace("YYYYMMDD", pTableNameReDate);
	 }
	 else if (pTableName.toUpperCase().contains("_MONYY")) {//&& !pTableName.contains("_YYYYMMDD")){
		 SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
		 Date d = format1.parse(pTableNameReDate);
		 SimpleDateFormat format2 = new SimpleDateFormat("ddMMMyy");
		 pTableName = pTableName.toUpperCase().replace("MONYY",format2.format(d).substring(2, 7));
		// pTableName = pTableName.toUpperCase().replace("MONYY",pTableNameReDate.substring(4, 2)+pTableNameReDate.substring(2, 2));
	 }
	 else if (pTableName.toUpperCase().contains("_YYYY_MM")) {//&& !pTableName.contains("_YYYYMMDD")){
		 //System.out.println(">>"+pTableName.toUpperCase());
		 SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
		 Date d = format1.parse(pTableNameReDate);
		 pTableName = pTableName.toUpperCase().replace("YYYY_MM",TalendDate.formatDate("yyyy_MM", d));
	 }
	return pTableName;
}
public static String GetTableNameByIndex(String pTableNameString,int pTableNameIndex){
	String[] str=pTableNameString.split(",");
	String result="Default_Table";
	//if (str.length<pTableNameIndex){
		result =str[pTableNameIndex];
	//}
	return str[pTableNameIndex];//result;
}

public static String getDataBaseNameByIndex(String pDBNameString,int pDBNameIndex){
	String[] str=pDBNameString.split(",");
	String result="Default_DB";
	//if (str.length<pTableNameIndex){
		result =str[pDBNameIndex];
	//}
	return str[pDBNameIndex];//result;
}

public static String getServerNameByIndex(String pServerNameString,int pServerNameIndex){
	String[] str=pServerNameString.split(",");
	String result="Default_DB";
	//if (str.length<pTableNameIndex){
		result =str[pServerNameIndex];
	//}
	return str[pServerNameIndex];//result;
}
public static Boolean isNumeric(String r,int i){
		return r.matches("\\d+");
} 
public static String AddFileExtention(String pFilename,String pRenameString)
{
	
		
	String result=pFilename+pRenameString;
	if(pRenameString==null)
		return result=pFilename;
	if(!pRenameString.isEmpty()||pRenameString!=null)
	{
		 
		if(pRenameString.contains(","))
		{
			
			String[] items=pRenameString.split(",");
			if(items.length==0)
			{
				
			}
			else
			{
				
				//if(items[0].isEmpty()||items[0]==""||items[0]==null || items[0].length()==0)
				if(items[0].equalsIgnoreCase("@"))
				{
					
					result=pFilename.toString()+items[1].toString();
					
					
				}
				else 
				{
					result=pFilename.toString().toUpperCase().replace(items[0].toString().toUpperCase(),items[1].toString().toUpperCase());
					
				}
				//globalMap.get("out1.basename").toString().toUpperCase().replace(context.vOldExtension,context.vNewExtension)
			}
		}
	}
	
	return result;
	}
public static String GetStringByLength(String pInputString, int pLength)
{
	String result="";
	if (pInputString !=null)
	{
		if (pInputString.length()>pLength-1)
		{
		result=pInputString.substring(0, pLength);
		}
		else 
		{
			result=pInputString;
		}
	}
	return result;
}

}
