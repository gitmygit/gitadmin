package routines;

import java.math.BigDecimal;


public class DelimiterCount {

   
    public static String Delimeter(String Srecord,char delim) 
    {
      int val1=0;
      val1=Srecord.indexOf("\"",0);
      int val2=0;
      if(val1>0)
      {
            val2=Srecord.substring(val1).lastIndexOf("\"",val1);
      }
      
      char[]third =Srecord.toCharArray();
        for(int counter =0;counter<third.length;counter++)
        {
        int count=0;
        for ( int i=0; i<third.length; i++)
        {
        if (delim==third[i])
        count++;
        
        }
      boolean flag=false;
      for(int j=counter-1;j>=0;j--)
      {
      if(delim==third[j])
      flag=true;
      }
      
      BigDecimal d= new BigDecimal(count);
      String StrD=d.toString();
      if(val1>0 && val2>0)
      {
            if(routines.DelimiterCount.Delimeter(Srecord.substring(val1+1,val1+val2),delim).equals("0"))
            {
                  return(StrD);
            }
            else
            {
                  BigDecimal sb=new BigDecimal(routines.DelimiterCount.Delimeter(Srecord.substring(val1+1,val1+val2),delim));
                  BigDecimal bd=new BigDecimal(StrD).subtract(sb);
                  return (bd.toString());
            }
      }
      else
      {
            return(StrD);
      }
      
      }
            return Srecord;
    }
}
