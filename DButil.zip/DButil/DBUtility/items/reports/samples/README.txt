column_report_01.jrxml: simple report with all its analyses
column_report_02.jrxml: report for history of indicators
overview_report_03.jrxml: simple report for connection analysis.
dq_rule_report_04.jrxml: simple report for table analysis.