package di_demo.dbutility_0_3;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.CitiEncryptUtil;
import routines.Relational;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendString;
import routines.StringHandling;
import routines.DQTechnical;
import routines.MDM;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

//the import part of tJavaRow_2
//import java.util.List;

//the import part of tJava_2
//import java.util.List;

//the import part of tJava_1
//import java.util.List;

@SuppressWarnings("unused")
/**
 * Job: DBUtility Purpose: <br>
 * Description:  <br>
 * @author sg26462@citi.com
 * @version 6.0.1.20160322_1633_patch
 * @status 
 */
public class DBUtility implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "DBUtility.log");
	}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger
			.getLogger(DBUtility.class);

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset
			.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (username != null) {

				this.setProperty("username", username.toString());

			}

			if (password != null) {

				this.setProperty("password", password.toString());

			}

			if (port != null) {

				this.setProperty("port", port.toString());

			}

			if (Query != null) {

				this.setProperty("Query", Query.toString());

			}

			if (host != null) {

				this.setProperty("host", host.toString());

			}

			if (Schema != null) {

				this.setProperty("Schema", Schema.toString());

			}

			if (cmd != null) {

				this.setProperty("cmd", cmd.toString());

			}

			if (database != null) {

				this.setProperty("database", database.toString());

			}

			if (storeproc != null) {

				this.setProperty("storeproc", storeproc.toString());

			}

			if (filepath != null) {

				this.setProperty("filepath", filepath.toString());

			}

			if (filename != null) {

				this.setProperty("filename", filename.toString());

			}

			if (tnsfile != null) {

				this.setProperty("tnsfile", tnsfile.toString());

			}

			if (url != null) {

				this.setProperty("url", url.toString());

			}

		}

		public String username;

		public String getUsername() {
			return this.username;
		}

		public java.lang.String password;

		public java.lang.String getPassword() {
			return this.password;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String Query;

		public String getQuery() {
			return this.Query;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String Schema;

		public String getSchema() {
			return this.Schema;
		}

		public String cmd;

		public String getCmd() {
			return this.cmd;
		}

		public String database;

		public String getDatabase() {
			return this.database;
		}

		public String storeproc;

		public String getStoreproc() {
			return this.storeproc;
		}

		public String filepath;

		public String getFilepath() {
			return this.filepath;
		}

		public String filename;

		public String getFilename() {
			return this.filename;
		}

		public String tnsfile;

		public String getTnsfile() {
			return this.tnsfile;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}
	}

	private ContextProperties context = new ContextProperties();

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.3";
	private final String jobName = "DBUtility";
	private final String projectName = "DI_DEMO";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	public boolean isExportedAsOSGI = false;

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(
			java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources
				.entrySet()) {
			talendDataSources.put(
					dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry
							.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null
						&& currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE",
							getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE",
						getExceptionCauseMessage(e));
				System.err
						.println("Exception in component " + currentComponent);
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					DBUtility.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(DBUtility.this, new Object[] { e,
									currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tBufferOutput_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tBufferOutput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tBufferInput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBufferInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tContextLoad_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tBufferInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleConnection_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tOracleConnection_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleInput_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		try {

			errorCode = null;
			tDie_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		tOracleInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tOracleInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDie_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDie_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleClose_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tOracleClose_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleSP_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tOracleSP_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleCommit_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tOracleCommit_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tJava_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDie_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDie_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDie_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDie_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		tOracleRow_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDie_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDie_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleCommit_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tOracleCommit_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tJava_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDie_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDie_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tAdvancedHash_row2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tBufferInput_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tOracleConnection_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "ERROR", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

		try {

			errorCode = null;
			tDie_4Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void tOracleInput_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDie_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tOracleClose_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tOracleSP_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tOracleCommit_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDie_4_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDie_5_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tOracleRow_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "ERROR", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

		try {

			errorCode = null;
			tDie_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void tDie_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tOracleCommit_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDie_3_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class urlStruct implements
			routines.system.IPersistableRow<urlStruct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(urlStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class out1Struct implements
			routines.system.IPersistableRow<out1Struct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class tns_aliasStruct implements
			routines.system.IPersistableRow<tns_aliasStruct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(tns_aliasStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements
			routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputDelimited_1Struct implements
			routines.system.IPersistableRow<after_tFileInputDelimited_1Struct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputDelimited_1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				tFileInputDelimited_2Process(globalMap);

				row4Struct row4 = new row4Struct();
				out1Struct out1 = new out1Struct();
				tns_aliasStruct tns_alias = new tns_aliasStruct();
				urlStruct url = new urlStruct();

				/**
				 * [tBufferOutput_2 begin ] start
				 */

				ok_Hash.put("tBufferOutput_2", false);
				start_Hash.put("tBufferOutput_2", System.currentTimeMillis());

				currentComponent = "tBufferOutput_2";

				int tos_count_tBufferOutput_2 = 0;

				/**
				 * [tBufferOutput_2 begin ] stop
				 */

				/**
				 * [tBufferOutput_1 begin ] start
				 */

				ok_Hash.put("tBufferOutput_1", false);
				start_Hash.put("tBufferOutput_1", System.currentTimeMillis());

				currentComponent = "tBufferOutput_1";

				int tos_count_tBufferOutput_1 = 0;

				/**
				 * [tBufferOutput_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				int tos_count_tMap_1 = 0;

				if (log.isInfoEnabled())
					log.info("tMap_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_1 = new StringBuilder();
				log4jParamters_tMap_1.append("Parameters:");
				log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + log4jParamters_tMap_1);

				// ###############################
				// # Lookup's keys initialization
				int count_tns_alias_tMap_1 = 0;

				int count_row2_tMap_1 = 0;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) globalMap
						.get("tHash_Lookup_row2"));

				row2Struct row2HashKey = new row2Struct();
				row2Struct row2Default = new row2Struct();
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_url_tMap_1 = 0;

				urlStruct url_tmp = new urlStruct();
				// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				int tos_count_tMap_2 = 0;

				if (log.isInfoEnabled())
					log.info("tMap_2 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_2 = new StringBuilder();
				log4jParamters_tMap_2.append("Parameters:");
				log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_2.append(" | ");
				log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_2.append(" | ");
				log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_2.append(" | ");
				log4jParamters_tMap_2
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + log4jParamters_tMap_2);

				// ###############################
				// # Lookup's keys initialization
				int count_row4_tMap_2 = 0;

				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_out1_tMap_2 = 0;

				out1Struct out1_tmp = new out1Struct();
				int count_tns_alias_tMap_2 = 0;

				tns_aliasStruct tns_alias_tmp = new tns_aliasStruct();
				// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1",
						System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				if (log.isInfoEnabled())
					log.info("tFileInputDelimited_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
				log4jParamters_tFileInputDelimited_1.append("Parameters:");
				log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = "
						+ "context.filepath+\"/\"+context.filename");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("CSV_OPTION"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("ROWSEPARATOR"
						+ " = " + "\"\\n\"");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR"
						+ " = " + "\"=\"");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("HEADER" + " = "
						+ "0");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = "
						+ "0");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = "
						+ "");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW"
						+ " = " + "true");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1
						.append("ADVANCED_SEPARATOR" + " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("RANDOM" + " = "
						+ "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = "
						+ "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("TRIMSELECT"
						+ " = " + "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("key") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("value") + "}]");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("CHECK_DATE"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("SPLITRECORD"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_1 - "
							+ log4jParamters_tFileInputDelimited_1);

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				try {

					Object filename_tFileInputDelimited_1 = context.filepath
							+ "/" + context.filename;
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0
								|| random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								context.filepath + "/" + context.filename,
								"ISO-8859-15", "=", "\n", true, 0, 0, -1, -1,
								false);
					} catch (java.lang.Exception e) {

						log.error("tFileInputDelimited_1 - " + e.getMessage());

						System.err.println(e.getMessage());

					}

					log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");

					while (fid_tFileInputDelimited_1 != null
							&& fid_tFileInputDelimited_1.nextRecord()) {

						row4 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row4 = new row4Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							columnIndexWithD_tFileInputDelimited_1 = 0;

							row4.key = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 1;

							row4.value = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

						} catch (java.lang.Exception e) {
							whetherReject_tFileInputDelimited_1 = true;

							log.error("tFileInputDelimited_1 - "
									+ e.getMessage());

							System.err.println(e.getMessage());
							row4 = null;

						}

						log.debug("tFileInputDelimited_1 - Retrieving the record "
								+ fid_tFileInputDelimited_1.getRowNumber()
								+ ".");

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */
						// Start of branch "row4"
						if (row4 != null) {

							/**
							 * [tMap_2 main ] start
							 */

							currentComponent = "tMap_2";

							if (log.isTraceEnabled()) {
								log.trace("row4 - "
										+ (row4 == null ? "" : row4
												.toLogString()));
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_2 = false;
							boolean mainRowRejected_tMap_2 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
								// ###############################
								// # Output tables

								out1 = null;
								tns_alias = null;

								// # Output table : 'out1'
								// # Filter conditions
								if (

								row4.key.startsWith(StringHandling
										.UPCASE(context.Schema))

								) {
									count_out1_tMap_2++;

									out1_tmp.key = StringHandling.EREPLACE(
											row4.key,
											StringHandling
													.UPCASE(context.Schema)
													+ "_", "");
									out1_tmp.value = row4.key
											.endsWith("_password") ? CitiEncryptUtil
											.decryptPassword(row4.value)
											: row4.value;
									out1 = out1_tmp;
									log.debug("tMap_2 - Outputting the record "
											+ count_out1_tMap_2
											+ " of the output table 'out1'.");

								} // closing filter/reject

								// # Output table : 'tns_alias'
								// # Filter conditions
								if (

								row4.key.startsWith(StringHandling
										.UPCASE(context.Schema) + "_alias")

								) {
									count_tns_alias_tMap_2++;

									tns_alias_tmp.key = row4.key;
									tns_alias_tmp.value = row4.value;
									tns_alias = tns_alias_tmp;
									log.debug("tMap_2 - Outputting the record "
											+ count_tns_alias_tMap_2
											+ " of the output table 'tns_alias'.");

								} // closing filter/reject
									// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_2 = false;

							tos_count_tMap_2++;

							/**
							 * [tMap_2 main ] stop
							 */
							// Start of branch "out1"
							if (out1 != null) {

								/**
								 * [tBufferOutput_2 main ] start
								 */

								currentComponent = "tBufferOutput_2";

								if (log.isTraceEnabled()) {
									log.trace("out1 - "
											+ (out1 == null ? "" : out1
													.toLogString()));
								}

								String[] row_tBufferOutput_2 = new String[] {
										"", "", };
								if (out1.key != null) {

									row_tBufferOutput_2[0] = out1.key;

								} else {
									row_tBufferOutput_2[0] = null;
								}
								if (out1.value != null) {

									row_tBufferOutput_2[1] = out1.value;

								} else {
									row_tBufferOutput_2[1] = null;
								}
								globalBuffer.add(row_tBufferOutput_2);

								tos_count_tBufferOutput_2++;

								/**
								 * [tBufferOutput_2 main ] stop
								 */

							} // End of branch "out1"

							// Start of branch "tns_alias"
							if (tns_alias != null) {

								/**
								 * [tMap_1 main ] start
								 */

								currentComponent = "tMap_1";

								if (log.isTraceEnabled()) {
									log.trace("tns_alias - "
											+ (tns_alias == null ? ""
													: tns_alias.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_1 = false;
								boolean mainRowRejected_tMap_1 = false;

								// /////////////////////////////////////////////
								// Starting Lookup Table "row2"
								// /////////////////////////////////////////////

								boolean forceLooprow2 = false;

								row2Struct row2ObjectFromLookup = null;

								if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

									hasCasePrimitiveKeyWithNull_tMap_1 = false;

									row2HashKey.key = tns_alias.value;

									row2HashKey.hashCodeDirty = true;

									tHash_Lookup_row2.lookup(row2HashKey);

									if (!tHash_Lookup_row2.hasNext()) { // G_TM_M_090

										rejectedInnerJoin_tMap_1 = true;

									} // G_TM_M_090

								} // G_TM_M_020

								if (tHash_Lookup_row2 != null
										&& tHash_Lookup_row2
												.getCount(row2HashKey) > 1) { // G
																				// 071

									// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row2' and it contains more one result from keys :  row2.key = '"
									// + row2HashKey.key + "'");
								} // G 071

								row2Struct row2 = null;

								row2Struct fromLookup_row2 = null;
								row2 = row2Default;

								if (tHash_Lookup_row2 != null
										&& tHash_Lookup_row2.hasNext()) { // G
																			// 099

									fromLookup_row2 = tHash_Lookup_row2.next();

								} // G 099

								if (fromLookup_row2 != null) {
									row2 = fromLookup_row2;
								}

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
									// ###############################
									// # Output tables

									url = null;

									if (!rejectedInnerJoin_tMap_1) {

										// # Output table : 'url'
										count_url_tMap_1++;

										url_tmp.key = "url";
										url_tmp.value = row2.value;
										url = url_tmp;
										log.debug("tMap_1 - Outputting the record "
												+ count_url_tMap_1
												+ " of the output table 'url'.");

									} // closing inner join bracket (2)
										// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_1 = false;

								tos_count_tMap_1++;

								/**
								 * [tMap_1 main ] stop
								 */
								// Start of branch "url"
								if (url != null) {

									/**
									 * [tBufferOutput_1 main ] start
									 */

									currentComponent = "tBufferOutput_1";

									if (log.isTraceEnabled()) {
										log.trace("url - "
												+ (url == null ? "" : url
														.toLogString()));
									}

									String[] row_tBufferOutput_1 = new String[] {
											"", "", };
									if (url.key != null) {

										row_tBufferOutput_1[0] = url.key;

									} else {
										row_tBufferOutput_1[0] = null;
									}
									if (url.value != null) {

										row_tBufferOutput_1[1] = url.value;

									} else {
										row_tBufferOutput_1[1] = null;
									}
									globalBuffer.add(row_tBufferOutput_1);

									tos_count_tBufferOutput_1++;

									/**
									 * [tBufferOutput_1 main ] stop
									 */

								} // End of branch "url"

							} // End of branch "tns_alias"

						} // End of branch "row4"

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) (context.filepath + "/" + context.filename) instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE",
								fid_tFileInputDelimited_1.getRowNumber());

						log.info("tFileInputDelimited_1 - Retrieved records count: "
								+ fid_tFileInputDelimited_1.getRowNumber()
								+ ".");

					}
				}

				if (log.isInfoEnabled())
					log.info("tFileInputDelimited_1 - " + "Done.");

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1",
						System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

				// ###############################
				// # Lookup hashes releasing
				// ###############################
				log.debug("tMap_2 - Written records count in the table 'out1': "
						+ count_out1_tMap_2 + ".");
				log.debug("tMap_2 - Written records count in the table 'tns_alias': "
						+ count_tns_alias_tMap_2 + ".");

				if (log.isInfoEnabled())
					log.info("tMap_2 - " + "Done.");

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tBufferOutput_2 end ] start
				 */

				currentComponent = "tBufferOutput_2";

				ok_Hash.put("tBufferOutput_2", true);
				end_Hash.put("tBufferOutput_2", System.currentTimeMillis());

				/**
				 * [tBufferOutput_2 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

				// ###############################
				// # Lookup hashes releasing
				if (tHash_Lookup_row2 != null) {
					tHash_Lookup_row2.endGet();
				}
				globalMap.remove("tHash_Lookup_row2");

				// ###############################
				log.debug("tMap_1 - Written records count in the table 'url': "
						+ count_url_tMap_1 + ".");

				if (log.isInfoEnabled())
					log.info("tMap_1 - " + "Done.");

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tBufferOutput_1 end ] start
				 */

				currentComponent = "tBufferOutput_1";

				ok_Hash.put("tBufferOutput_1", true);
				end_Hash.put("tBufferOutput_1", System.currentTimeMillis());

				/**
				 * [tBufferOutput_1 end ] stop
				 */

			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tBufferInput_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row2");

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tBufferOutput_2 finally ] start
				 */

				currentComponent = "tBufferOutput_2";

				/**
				 * [tBufferOutput_2 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tBufferOutput_1 finally ] start
				 */

				currentComponent = "tBufferOutput_1";

				/**
				 * [tBufferOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class row3Struct implements
			routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

					this.value = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

				// String

				writeString(this.value, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tBufferInput_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tBufferInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();

				/**
				 * [tContextLoad_2 begin ] start
				 */

				ok_Hash.put("tContextLoad_2", false);
				start_Hash.put("tContextLoad_2", System.currentTimeMillis());

				currentComponent = "tContextLoad_2";

				int tos_count_tContextLoad_2 = 0;

				if (log.isInfoEnabled())
					log.info("tContextLoad_2 - " + "Start to work.");
				StringBuilder log4jParamters_tContextLoad_2 = new StringBuilder();
				log4jParamters_tContextLoad_2.append("Parameters:");
				log4jParamters_tContextLoad_2.append("LOAD_NEW_VARIABLE"
						+ " = " + "Warning");
				log4jParamters_tContextLoad_2.append(" | ");
				log4jParamters_tContextLoad_2.append("NOT_LOAD_OLD_VARIABLE"
						+ " = " + "Warning");
				log4jParamters_tContextLoad_2.append(" | ");
				log4jParamters_tContextLoad_2.append("PRINT_OPERATIONS" + " = "
						+ "false");
				log4jParamters_tContextLoad_2.append(" | ");
				log4jParamters_tContextLoad_2.append("DISABLE_ERROR" + " = "
						+ "false");
				log4jParamters_tContextLoad_2.append(" | ");
				log4jParamters_tContextLoad_2.append("DISABLE_WARNINGS" + " = "
						+ "true");
				log4jParamters_tContextLoad_2.append(" | ");
				log4jParamters_tContextLoad_2.append("DISABLE_INFO" + " = "
						+ "true");
				log4jParamters_tContextLoad_2.append(" | ");
				log4jParamters_tContextLoad_2.append("DIEONERROR" + " = "
						+ "false");
				log4jParamters_tContextLoad_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tContextLoad_2 - "
							+ log4jParamters_tContextLoad_2);
				java.util.List<String> assignList_tContextLoad_2 = new java.util.ArrayList<String>();
				java.util.List<String> newPropertyList_tContextLoad_2 = new java.util.ArrayList<String>();
				java.util.List<String> noAssignList_tContextLoad_2 = new java.util.ArrayList<String>();
				int nb_line_tContextLoad_2 = 0;

				/**
				 * [tContextLoad_2 begin ] stop
				 */

				/**
				 * [tBufferInput_1 begin ] start
				 */

				ok_Hash.put("tBufferInput_1", false);
				start_Hash.put("tBufferInput_1", System.currentTimeMillis());

				currentComponent = "tBufferInput_1";

				int tos_count_tBufferInput_1 = 0;

				int nb_line_tBufferInput_1 = 0;

				String[] row_tBufferInput_1 = new String[2];
				for (int n = 0; n < globalBuffer.size(); n++) {
					row_tBufferInput_1 = (String[]) globalBuffer.get(n);
					if (0 < row_tBufferInput_1.length) {

						row3.key = row_tBufferInput_1[0];

					}

					else {
						row3.key = null;
					}
					if (1 < row_tBufferInput_1.length) {

						row3.value = row_tBufferInput_1[1];

					}

					else {
						row3.value = null;
					}

					/**
					 * [tBufferInput_1 begin ] stop
					 */

					/**
					 * [tBufferInput_1 main ] start
					 */

					currentComponent = "tBufferInput_1";

					tos_count_tBufferInput_1++;

					/**
					 * [tBufferInput_1 main ] stop
					 */

					/**
					 * [tContextLoad_2 main ] start
					 */

					currentComponent = "tContextLoad_2";

					if (log.isTraceEnabled()) {
						log.trace("row3 - "
								+ (row3 == null ? "" : row3.toLogString()));
					}

					// ////////////////////////
					String tmp_key_tContextLoad_2 = null;
					String key_tContextLoad_2 = null;
					if (row3.key != null) {
						tmp_key_tContextLoad_2 = row3.key.trim();
						if ((tmp_key_tContextLoad_2.startsWith("#") || tmp_key_tContextLoad_2
								.startsWith("!"))) {
							tmp_key_tContextLoad_2 = null;
						} else {
							row3.key = tmp_key_tContextLoad_2;
						}
					}
					if (row3.key != null) {
						key_tContextLoad_2 = row3.key;
					}
					String value_tContextLoad_2 = null;
					if (row3.value != null) {
						value_tContextLoad_2 = row3.value;
					}

					if (tmp_key_tContextLoad_2 != null) {
						try {
							if (key_tContextLoad_2 != null
									&& "username".equals(key_tContextLoad_2)) {
								context.username = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "password".equals(key_tContextLoad_2)) {
								context.password = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "port".equals(key_tContextLoad_2)) {
								context.port = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "Query".equals(key_tContextLoad_2)) {
								context.Query = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "host".equals(key_tContextLoad_2)) {
								context.host = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "Schema".equals(key_tContextLoad_2)) {
								context.Schema = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "cmd".equals(key_tContextLoad_2)) {
								context.cmd = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "database".equals(key_tContextLoad_2)) {
								context.database = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "storeproc".equals(key_tContextLoad_2)) {
								context.storeproc = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "filepath".equals(key_tContextLoad_2)) {
								context.filepath = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "filename".equals(key_tContextLoad_2)) {
								context.filename = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "tnsfile".equals(key_tContextLoad_2)) {
								context.tnsfile = value_tContextLoad_2;
							}

							if (key_tContextLoad_2 != null
									&& "url".equals(key_tContextLoad_2)) {
								context.url = value_tContextLoad_2;
							}

							if (context.getProperty(key_tContextLoad_2) != null) {
								assignList_tContextLoad_2
										.add(key_tContextLoad_2);
							} else {
								newPropertyList_tContextLoad_2
										.add(key_tContextLoad_2);
							}
							if (value_tContextLoad_2 == null) {
								context.setProperty(key_tContextLoad_2, "");
							} else {
								context.setProperty(key_tContextLoad_2,
										value_tContextLoad_2);
							}
						} catch (java.lang.Exception e) {
							log.error("tContextLoad_2 - Setting a value for the key \""
									+ key_tContextLoad_2
									+ "\" has failed. Error message: "
									+ e.getMessage());
							System.err.println("Setting a value for the key \""
									+ key_tContextLoad_2
									+ "\" has failed. Error message: "
									+ e.getMessage());
						}
						nb_line_tContextLoad_2++;
					}
					// ////////////////////////

					tos_count_tContextLoad_2++;

					/**
					 * [tContextLoad_2 main ] stop
					 */

					/**
					 * [tBufferInput_1 end ] start
					 */

					currentComponent = "tBufferInput_1";

					nb_line_tBufferInput_1++;
				}
				globalMap.put("tBufferInput_1_NB_LINE", nb_line_tBufferInput_1);

				ok_Hash.put("tBufferInput_1", true);
				end_Hash.put("tBufferInput_1", System.currentTimeMillis());

				/**
				 * [tBufferInput_1 end ] stop
				 */

				/**
				 * [tContextLoad_2 end ] start
				 */

				currentComponent = "tContextLoad_2";

				java.util.Enumeration<?> enu_tContextLoad_2 = context
						.propertyNames();
				while (enu_tContextLoad_2.hasMoreElements()) {
					String key_tContextLoad_2 = (String) enu_tContextLoad_2
							.nextElement();
					if (!assignList_tContextLoad_2.contains(key_tContextLoad_2)
							&& !newPropertyList_tContextLoad_2
									.contains(key_tContextLoad_2)) {
						noAssignList_tContextLoad_2.add(key_tContextLoad_2);
					}
				}

				String newPropertyStr_tContextLoad_2 = newPropertyList_tContextLoad_2
						.toString();
				String newProperty_tContextLoad_2 = newPropertyStr_tContextLoad_2
						.substring(1,
								newPropertyStr_tContextLoad_2.length() - 1);

				String noAssignStr_tContextLoad_2 = noAssignList_tContextLoad_2
						.toString();
				String noAssign_tContextLoad_2 = noAssignStr_tContextLoad_2
						.substring(1, noAssignStr_tContextLoad_2.length() - 1);

				globalMap.put("tContextLoad_2_KEY_NOT_INCONTEXT",
						newProperty_tContextLoad_2);
				globalMap.put("tContextLoad_2_KEY_NOT_LOADED",
						noAssign_tContextLoad_2);

				globalMap.put("tContextLoad_2_NB_LINE", nb_line_tContextLoad_2);

				List<String> parametersToEncrypt_tContextLoad_2 = new java.util.ArrayList<String>();

				parametersToEncrypt_tContextLoad_2.add("password");

				resumeUtil.addLog("NODE", "NODE:tContextLoad_2", "", Thread
						.currentThread().getId() + "", "", "", "", "",
						resumeUtil.convertToJsonText(context,
								parametersToEncrypt_tContextLoad_2));
				log.info("tContextLoad_2 - Loaded contexts count: "
						+ nb_line_tContextLoad_2 + ".");

				if (log.isInfoEnabled())
					log.info("tContextLoad_2 - " + "Done.");

				ok_Hash.put("tContextLoad_2", true);
				end_Hash.put("tContextLoad_2", System.currentTimeMillis());

				if (((Integer) globalMap.get("tContextLoad_2_NB_LINE")) > 4) {

					tOracleConnection_1Process(globalMap);
				}

				if (((Integer) globalMap.get("tContextLoad_2_NB_LINE")) < 4) {

					tDie_3Process(globalMap);
				}

				/**
				 * [tContextLoad_2 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tBufferInput_1 finally ] start
				 */

				currentComponent = "tBufferInput_1";

				/**
				 * [tBufferInput_1 finally ] stop
				 */

				/**
				 * [tContextLoad_2 finally ] start
				 */

				currentComponent = "tContextLoad_2";

				/**
				 * [tContextLoad_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tBufferInput_1_SUBPROCESS_STATE", 1);
	}

	public void tOracleConnection_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tOracleConnection_1 begin ] start
				 */

				ok_Hash.put("tOracleConnection_1", false);
				start_Hash.put("tOracleConnection_1",
						System.currentTimeMillis());

				currentComponent = "tOracleConnection_1";

				int tos_count_tOracleConnection_1 = 0;

				if (log.isInfoEnabled())
					log.info("tOracleConnection_1 - " + "Start to work.");
				StringBuilder log4jParamters_tOracleConnection_1 = new StringBuilder();
				log4jParamters_tOracleConnection_1.append("Parameters:");
				log4jParamters_tOracleConnection_1.append("CONNECTION_TYPE"
						+ " = " + "ORACLE_RAC");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("DB_VERSION" + " = "
						+ "ORACLE_11");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("RAC_URL" + " = "
						+ "context.url");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("SCHEMA_DB" + " = "
						+ "context.Schema");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("USER" + " = "
						+ "context.username");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("PASS"
						+ " = "
						+ String.valueOf(
								routines.system.PasswordEncryptUtil
										.encryptPassword(context.password))
								.substring(0, 4) + "...");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1
						.append("USE_SHARED_CONNECTION" + " = " + "false");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1
						.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
				log4jParamters_tOracleConnection_1.append(" | ");
				log4jParamters_tOracleConnection_1.append("AUTO_COMMIT" + " = "
						+ "false");
				log4jParamters_tOracleConnection_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tOracleConnection_1 - "
							+ log4jParamters_tOracleConnection_1);

				String url_tOracleConnection_1 = context.url;
				globalMap.put("connectionType_" + "tOracleConnection_1",
						"ORACLE_RAC");

				String dbUser_tOracleConnection_1 = context.username;

				final String decryptedPassword_tOracleConnection_1 = context.password;
				String dbPwd_tOracleConnection_1 = decryptedPassword_tOracleConnection_1;

				java.sql.Connection conn_tOracleConnection_1 = null;

				String driverClass_tOracleConnection_1 = "oracle.jdbc.OracleDriver";
				java.lang.Class.forName(driverClass_tOracleConnection_1);

				log.debug("tOracleConnection_1 - Driver ClassName: "
						+ driverClass_tOracleConnection_1 + ".");

				log.info("tOracleConnection_1 - Connection attempt to '"
						+ url_tOracleConnection_1 + "' with the username '"
						+ dbUser_tOracleConnection_1 + "'.");

				conn_tOracleConnection_1 = java.sql.DriverManager
						.getConnection(url_tOracleConnection_1,
								dbUser_tOracleConnection_1,
								dbPwd_tOracleConnection_1);
				log.info("tOracleConnection_1 - Connection to '"
						+ url_tOracleConnection_1 + "' has succeeded.");

				globalMap.put("conn_tOracleConnection_1",
						conn_tOracleConnection_1);
				if (null != conn_tOracleConnection_1) {

					log.debug("tOracleConnection_1 - Connection is set auto commit to 'false'.");
					conn_tOracleConnection_1.setAutoCommit(false);
				}
				globalMap.put("rac_url_" + "tOracleConnection_1", context.url);

				globalMap.put("conn_" + "tOracleConnection_1",
						conn_tOracleConnection_1);
				globalMap.put("dbschema_" + "tOracleConnection_1",
						context.Schema);
				globalMap.put("username_" + "tOracleConnection_1",
						context.username);
				globalMap.put("password_" + "tOracleConnection_1",
						dbPwd_tOracleConnection_1);

				/**
				 * [tOracleConnection_1 begin ] stop
				 */

				/**
				 * [tOracleConnection_1 main ] start
				 */

				currentComponent = "tOracleConnection_1";

				tos_count_tOracleConnection_1++;

				/**
				 * [tOracleConnection_1 main ] stop
				 */

				/**
				 * [tOracleConnection_1 end ] start
				 */

				currentComponent = "tOracleConnection_1";

				if (log.isInfoEnabled())
					log.info("tOracleConnection_1 - " + "Done.");

				ok_Hash.put("tOracleConnection_1", true);
				end_Hash.put("tOracleConnection_1", System.currentTimeMillis());

				if (StringHandling.UPCASE(context.cmd).equals("SELECT")) {

					tOracleInput_2Process(globalMap);
				}

				if (StringHandling.UPCASE(context.cmd).equals("PROC")) {

					tOracleSP_1Process(globalMap);
				}

				if (!(StringHandling.UPCASE(context.cmd).equals("SELECT")
						|| StringHandling.UPCASE(context.cmd).equals("INSERT")
						|| StringHandling.UPCASE(context.cmd).equals("UPDATE")
						|| StringHandling.UPCASE(context.cmd).equals("DELETE") || StringHandling
						.UPCASE(context.cmd).equals("PROC"))) {

					tDie_5Process(globalMap);
				}

				if (StringHandling.UPCASE(context.cmd).equals("INSERT")
						|| StringHandling.UPCASE(context.cmd).equals("UPDATE")
						|| StringHandling.UPCASE(context.cmd).equals("DELETE")) {

					tOracleRow_1Process(globalMap);
				}

				/**
				 * [tOracleConnection_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleConnection_1 finally ] start
				 */

				currentComponent = "tOracleConnection_1";

				/**
				 * [tOracleConnection_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", 1);
	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];

		public routines.system.Dynamic value;

		public routines.system.Dynamic getValue() {
			return this.value;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.value = (routines.system.Dynamic) dis.readObject();

				} catch (IOException e) {
					throw new RuntimeException(e);

				} catch (ClassNotFoundException eCNFE) {
					throw new RuntimeException(eCNFE);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Dynamic

				dos.writeObject(this.value);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("value=" + String.valueOf(value));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tOracleInput_2Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleInput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();

				/**
				 * [tJavaRow_2 begin ] start
				 */

				ok_Hash.put("tJavaRow_2", false);
				start_Hash.put("tJavaRow_2", System.currentTimeMillis());

				currentComponent = "tJavaRow_2";

				int tos_count_tJavaRow_2 = 0;

				int nb_line_tJavaRow_2 = 0;

				/**
				 * [tJavaRow_2 begin ] stop
				 */

				/**
				 * [tOracleInput_2 begin ] start
				 */

				ok_Hash.put("tOracleInput_2", false);
				start_Hash.put("tOracleInput_2", System.currentTimeMillis());

				currentComponent = "tOracleInput_2";

				int tos_count_tOracleInput_2 = 0;

				if (log.isInfoEnabled())
					log.info("tOracleInput_2 - " + "Start to work.");
				StringBuilder log4jParamters_tOracleInput_2 = new StringBuilder();
				log4jParamters_tOracleInput_2.append("Parameters:");
				log4jParamters_tOracleInput_2.append("USE_EXISTING_CONNECTION"
						+ " = " + "true");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("CONNECTION" + " = "
						+ "tOracleConnection_1");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("TABLE" + " = " + "\"\"");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("QUERY" + " = "
						+ "context.Query");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("IS_CONVERT_XMLTYPE"
						+ " = " + "false");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("USE_CURSOR" + " = "
						+ "false");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("TRIM_ALL_COLUMN" + " = "
						+ "false");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("TRIM_COLUMN" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("value") + "}]");
				log4jParamters_tOracleInput_2.append(" | ");
				log4jParamters_tOracleInput_2.append("NO_NULL_VALUES" + " = "
						+ "false");
				log4jParamters_tOracleInput_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tOracleInput_2 - "
							+ log4jParamters_tOracleInput_2);

				int nb_line_tOracleInput_2 = 0;
				java.sql.Connection conn_tOracleInput_2 = null;
				conn_tOracleInput_2 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				if (conn_tOracleInput_2 != null) {
					if (conn_tOracleInput_2.getMetaData() != null) {

						log.info("tOracleInput_2 - Uses an existing connection with username '"
								+ conn_tOracleInput_2.getMetaData()
										.getUserName()
								+ "'. Connection URL: "
								+ conn_tOracleInput_2.getMetaData().getURL()
								+ ".");

					}
				}

				if (((oracle.jdbc.OracleConnection) conn_tOracleInput_2)
						.getSessionTimeZone() == null) {
					java.sql.Statement stmtGetTZ_tOracleInput_2 = conn_tOracleInput_2
							.createStatement();
					java.sql.ResultSet rsGetTZ_tOracleInput_2 = stmtGetTZ_tOracleInput_2
							.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tOracleInput_2 = java.util.TimeZone
							.getDefault().getID();
					while (rsGetTZ_tOracleInput_2.next()) {
						sessionTimezone_tOracleInput_2 = rsGetTZ_tOracleInput_2
								.getString(1);
					}
					((oracle.jdbc.OracleConnection) conn_tOracleInput_2)
							.setSessionTimeZone(sessionTimezone_tOracleInput_2);
				}

				java.sql.Statement stmt_tOracleInput_2 = conn_tOracleInput_2
						.createStatement();

				String dbquery_tOracleInput_2 = context.Query;

				log.info("tOracleInput_2 - Executing the query: '"
						+ dbquery_tOracleInput_2 + "'.");

				globalMap.put("tOracleInput_2_QUERY", dbquery_tOracleInput_2);

				java.sql.ResultSet rs_tOracleInput_2 = null;
				try {
					rs_tOracleInput_2 = stmt_tOracleInput_2
							.executeQuery(dbquery_tOracleInput_2);
					java.sql.ResultSetMetaData rsmd_tOracleInput_2 = rs_tOracleInput_2
							.getMetaData();
					int colQtyInRs_tOracleInput_2 = rsmd_tOracleInput_2
							.getColumnCount();

					routines.system.Dynamic dcg_tOracleInput_2 = new routines.system.Dynamic();
					dcg_tOracleInput_2.setDbmsId("oracle_id");
					List<String> listSchema_tOracleInput_2 = new java.util.ArrayList<String>();

					int fixedColumnCount_tOracleInput_2 = 0;

					for (int i = 1; i <= rsmd_tOracleInput_2.getColumnCount() - 0; i++) {
						if (!(listSchema_tOracleInput_2
								.contains(rsmd_tOracleInput_2.getColumnLabel(i)
										.toUpperCase()))) {
							routines.system.DynamicMetadata dcm_tOracleInput_2 = new routines.system.DynamicMetadata();
							dcm_tOracleInput_2.setName(rsmd_tOracleInput_2
									.getColumnLabel(i));
							dcm_tOracleInput_2.setDbName(rsmd_tOracleInput_2
									.getColumnName(i));
							dcm_tOracleInput_2
									.setType(routines.system.Dynamic
											.getTalendTypeFromDBType(
													"oracle_id",
													rsmd_tOracleInput_2
															.getColumnTypeName(
																	i)
															.toUpperCase(),
													rsmd_tOracleInput_2
															.getPrecision(i),
													rsmd_tOracleInput_2
															.getScale(i)));
							dcm_tOracleInput_2.setDbType(rsmd_tOracleInput_2
									.getColumnTypeName(i));
							dcm_tOracleInput_2.setDbTypeId(rsmd_tOracleInput_2
									.getColumnType(i));
							dcm_tOracleInput_2.setFormat("MM/dd/yyyy");
							if ("LONG".equals(rsmd_tOracleInput_2
									.getColumnTypeName(i).toUpperCase())) {
								String length = MetadataTalendType
										.getDefaultDBTypes(
												"oracle_id",
												"LONG",
												MetadataTalendType.DEFAULT_LENGTH);
								if (length != null && !("".equals(length))) {
									dcm_tOracleInput_2.setLength(Integer
											.parseInt(length));
								} else {
									dcm_tOracleInput_2
											.setLength(rsmd_tOracleInput_2
													.getPrecision(i));
								}
							} else {
								dcm_tOracleInput_2
										.setLength(rsmd_tOracleInput_2
												.getPrecision(i));
							}
							dcm_tOracleInput_2.setPrecision(rsmd_tOracleInput_2
									.getScale(i));
							dcm_tOracleInput_2.setNullable(rsmd_tOracleInput_2
									.isNullable(i) == 0 ? false : true);
							dcm_tOracleInput_2.setKey(false);
							dcm_tOracleInput_2
									.setSourceType(DynamicMetadata.sourceTypes.database);
							dcm_tOracleInput_2.setColumnPosition(i);
							dcg_tOracleInput_2.metadatas
									.add(dcm_tOracleInput_2);
						}
					}
					String tmpContent_tOracleInput_2 = null;

					int column_index_tOracleInput_2 = 1;

					log.info("tOracleInput_2 - Retrieving records from the database.");

					while (rs_tOracleInput_2.next()) {
						nb_line_tOracleInput_2++;

						column_index_tOracleInput_2 = 1;

						if (colQtyInRs_tOracleInput_2 < column_index_tOracleInput_2) {
							row1.value = null;
						} else {
							row1.value = dcg_tOracleInput_2;
							routines.system.DynamicUtils
									.readColumnsFromDatabase(row1.value,
											rs_tOracleInput_2,
											fixedColumnCount_tOracleInput_2,
											false);
						}

						log.debug("tOracleInput_2 - Retrieving the record "
								+ nb_line_tOracleInput_2 + ".");

						/**
						 * [tOracleInput_2 begin ] stop
						 */

						/**
						 * [tOracleInput_2 main ] start
						 */

						currentComponent = "tOracleInput_2";

						tos_count_tOracleInput_2++;

						/**
						 * [tOracleInput_2 main ] stop
						 */

						/**
						 * [tJavaRow_2 main ] start
						 */

						currentComponent = "tJavaRow_2";

						if (log.isTraceEnabled()) {
							log.trace("row1 - "
									+ (row1 == null ? "" : row1.toLogString()));
						}

						// Code generated according to input schema and output
						// schema
						System.out.println(row1.value);

						nb_line_tJavaRow_2++;

						tos_count_tJavaRow_2++;

						/**
						 * [tJavaRow_2 main ] stop
						 */

						/**
						 * [tOracleInput_2 end ] start
						 */

						currentComponent = "tOracleInput_2";

					}
				} finally {
					stmt_tOracleInput_2.close();

				}

				globalMap.put("tOracleInput_2_NB_LINE", nb_line_tOracleInput_2);
				log.info("tOracleInput_2 - Retrieved records count: "
						+ nb_line_tOracleInput_2 + " .");

				if (log.isInfoEnabled())
					log.info("tOracleInput_2 - " + "Done.");

				ok_Hash.put("tOracleInput_2", true);
				end_Hash.put("tOracleInput_2", System.currentTimeMillis());

				/**
				 * [tOracleInput_2 end ] stop
				 */

				/**
				 * [tJavaRow_2 end ] start
				 */

				currentComponent = "tJavaRow_2";

				globalMap.put("tJavaRow_2_NB_LINE", nb_line_tJavaRow_2);

				ok_Hash.put("tJavaRow_2", true);
				end_Hash.put("tJavaRow_2", System.currentTimeMillis());

				/**
				 * [tJavaRow_2 end ] stop
				 */

			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tOracleInput_2:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tOracleClose_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleInput_2 finally ] start
				 */

				currentComponent = "tOracleInput_2";

				/**
				 * [tOracleInput_2 finally ] stop
				 */

				/**
				 * [tJavaRow_2 finally ] start
				 */

				currentComponent = "tJavaRow_2";

				/**
				 * [tJavaRow_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleInput_2_SUBPROCESS_STATE", 1);
	}

	public void tDie_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tDie_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tDie_1 begin ] start
				 */

				ok_Hash.put("tDie_1", false);
				start_Hash.put("tDie_1", System.currentTimeMillis());

				currentComponent = "tDie_1";

				int tos_count_tDie_1 = 0;

				if (log.isInfoEnabled())
					log.info("tDie_1 - " + "Start to work.");
				StringBuilder log4jParamters_tDie_1 = new StringBuilder();
				log4jParamters_tDie_1.append("Parameters:");
				log4jParamters_tDie_1
						.append("MESSAGE"
								+ " = "
								+ "\"Load Failed for Query : \"+ context.Query + \" with error message :\"+((String)globalMap.get(\"tOracleInput_2_ERROR_MESSAGE\"))");
				log4jParamters_tDie_1.append(" | ");
				log4jParamters_tDie_1.append("CODE" + " = " + "4");
				log4jParamters_tDie_1.append(" | ");
				log4jParamters_tDie_1.append("PRIORITY" + " = " + "5");
				log4jParamters_tDie_1.append(" | ");
				log4jParamters_tDie_1.append("EXIT_JVM" + " = " + "false");
				log4jParamters_tDie_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tDie_1 - " + log4jParamters_tDie_1);

				/**
				 * [tDie_1 begin ] stop
				 */

				/**
				 * [tDie_1 main ] start
				 */

				currentComponent = "tDie_1";

				globalMap.put("tDie_1_DIE_PRIORITY", 5);
				System.err.println("Load Failed for Query : "
						+ context.Query
						+ " with error message :"
						+ ((String) globalMap
								.get("tOracleInput_2_ERROR_MESSAGE")));

				log.error("tDie_1 - The die message: "
						+ "Load Failed for Query : "
						+ context.Query
						+ " with error message :"
						+ ((String) globalMap
								.get("tOracleInput_2_ERROR_MESSAGE")));

				globalMap.put(
						"tDie_1_DIE_MESSAGE",
						"Load Failed for Query : "
								+ context.Query
								+ " with error message :"
								+ ((String) globalMap
										.get("tOracleInput_2_ERROR_MESSAGE")));
				globalMap.put(
						"tDie_1_DIE_MESSAGES",
						"Load Failed for Query : "
								+ context.Query
								+ " with error message :"
								+ ((String) globalMap
										.get("tOracleInput_2_ERROR_MESSAGE")));
				currentComponent = "tDie_1";
				status = "failure";
				errorCode = new Integer(4);
				globalMap.put("tDie_1_DIE_CODE", errorCode);

				if (true) {
					throw new TDieException();
				}

				tos_count_tDie_1++;

				/**
				 * [tDie_1 main ] stop
				 */

				/**
				 * [tDie_1 end ] start
				 */

				currentComponent = "tDie_1";

				if (log.isInfoEnabled())
					log.info("tDie_1 - " + "Done.");

				ok_Hash.put("tDie_1", true);
				end_Hash.put("tDie_1", System.currentTimeMillis());

				/**
				 * [tDie_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDie_1 finally ] start
				 */

				currentComponent = "tDie_1";

				/**
				 * [tDie_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDie_1_SUBPROCESS_STATE", 1);
	}

	public void tOracleClose_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleClose_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tOracleClose_1 begin ] start
				 */

				ok_Hash.put("tOracleClose_1", false);
				start_Hash.put("tOracleClose_1", System.currentTimeMillis());

				currentComponent = "tOracleClose_1";

				int tos_count_tOracleClose_1 = 0;

				if (log.isInfoEnabled())
					log.info("tOracleClose_1 - " + "Start to work.");
				StringBuilder log4jParamters_tOracleClose_1 = new StringBuilder();
				log4jParamters_tOracleClose_1.append("Parameters:");
				log4jParamters_tOracleClose_1.append("CONNECTION" + " = "
						+ "tOracleConnection_1");
				log4jParamters_tOracleClose_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tOracleClose_1 - "
							+ log4jParamters_tOracleClose_1);

				/**
				 * [tOracleClose_1 begin ] stop
				 */

				/**
				 * [tOracleClose_1 main ] start
				 */

				currentComponent = "tOracleClose_1";

				java.sql.Connection conn_tOracleClose_1 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				if (conn_tOracleClose_1 != null
						&& !conn_tOracleClose_1.isClosed()) {

					log.info("tOracleClose_1 - Closing the connection 'tOracleConnection_1' to the database.");

					conn_tOracleClose_1.close();

					log.info("tOracleClose_1 - Connection 'tOracleConnection_1' to the database closed.");

				}

				tos_count_tOracleClose_1++;

				/**
				 * [tOracleClose_1 main ] stop
				 */

				/**
				 * [tOracleClose_1 end ] start
				 */

				currentComponent = "tOracleClose_1";

				if (log.isInfoEnabled())
					log.info("tOracleClose_1 - " + "Done.");

				ok_Hash.put("tOracleClose_1", true);
				end_Hash.put("tOracleClose_1", System.currentTimeMillis());

				/**
				 * [tOracleClose_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleClose_1 finally ] start
				 */

				currentComponent = "tOracleClose_1";

				/**
				 * [tOracleClose_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleClose_1_SUBPROCESS_STATE", 1);
	}

	public void tOracleSP_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleSP_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tOracleSP_1 begin ] start
				 */

				ok_Hash.put("tOracleSP_1", false);
				start_Hash.put("tOracleSP_1", System.currentTimeMillis());

				currentComponent = "tOracleSP_1";

				int tos_count_tOracleSP_1 = 0;

				java.sql.Connection connection_tOracleSP_1 = null;
				connection_tOracleSP_1 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				java.sql.CallableStatement statement_tOracleSP_1 = connection_tOracleSP_1
						.prepareCall("{call " + context.storeproc + "()}");

				java.sql.Timestamp tmpDate_tOracleSP_1;
				String tmpString_tOracleSP_1;

				/**
				 * [tOracleSP_1 begin ] stop
				 */

				/**
				 * [tOracleSP_1 main ] start
				 */

				currentComponent = "tOracleSP_1";

				statement_tOracleSP_1.execute();

				tos_count_tOracleSP_1++;

				/**
				 * [tOracleSP_1 main ] stop
				 */

				/**
				 * [tOracleSP_1 end ] start
				 */

				currentComponent = "tOracleSP_1";

				statement_tOracleSP_1.close();

				ok_Hash.put("tOracleSP_1", true);
				end_Hash.put("tOracleSP_1", System.currentTimeMillis());

				/**
				 * [tOracleSP_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tOracleSP_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tOracleCommit_2Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleSP_1 finally ] start
				 */

				currentComponent = "tOracleSP_1";

				/**
				 * [tOracleSP_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleSP_1_SUBPROCESS_STATE", 1);
	}

	public void tOracleCommit_2Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleCommit_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tOracleCommit_2 begin ] start
				 */

				ok_Hash.put("tOracleCommit_2", false);
				start_Hash.put("tOracleCommit_2", System.currentTimeMillis());

				currentComponent = "tOracleCommit_2";

				int tos_count_tOracleCommit_2 = 0;

				if (log.isInfoEnabled())
					log.info("tOracleCommit_2 - " + "Start to work.");
				StringBuilder log4jParamters_tOracleCommit_2 = new StringBuilder();
				log4jParamters_tOracleCommit_2.append("Parameters:");
				log4jParamters_tOracleCommit_2.append("CONNECTION" + " = "
						+ "tOracleConnection_1");
				log4jParamters_tOracleCommit_2.append(" | ");
				log4jParamters_tOracleCommit_2.append("CLOSE" + " = " + "true");
				log4jParamters_tOracleCommit_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tOracleCommit_2 - "
							+ log4jParamters_tOracleCommit_2);

				/**
				 * [tOracleCommit_2 begin ] stop
				 */

				/**
				 * [tOracleCommit_2 main ] start
				 */

				currentComponent = "tOracleCommit_2";

				java.sql.Connection conn_tOracleCommit_2 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				if (conn_tOracleCommit_2 != null
						&& !conn_tOracleCommit_2.isClosed()) {

					try {

						log.debug("tOracleCommit_2 - Connection 'tOracleConnection_1' starting to commit.");

						conn_tOracleCommit_2.commit();

						log.debug("tOracleCommit_2 - Connection 'tOracleConnection_1' commit has succeeded.");

					} finally {

						log.info("tOracleCommit_2 - Closing the connection 'tOracleConnection_1' to the database.");

						conn_tOracleCommit_2.close();

						log.info("tOracleCommit_2 - Connection 'tOracleConnection_1' to the database closed.");

					}

				}

				tos_count_tOracleCommit_2++;

				/**
				 * [tOracleCommit_2 main ] stop
				 */

				/**
				 * [tOracleCommit_2 end ] start
				 */

				currentComponent = "tOracleCommit_2";

				if (log.isInfoEnabled())
					log.info("tOracleCommit_2 - " + "Done.");

				ok_Hash.put("tOracleCommit_2", true);
				end_Hash.put("tOracleCommit_2", System.currentTimeMillis());

				/**
				 * [tOracleCommit_2 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tOracleCommit_2:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tJava_2Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleCommit_2 finally ] start
				 */

				currentComponent = "tOracleCommit_2";

				/**
				 * [tOracleCommit_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleCommit_2_SUBPROCESS_STATE", 1);
	}

	public void tJava_2Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_2 begin ] start
				 */

				ok_Hash.put("tJava_2", false);
				start_Hash.put("tJava_2", System.currentTimeMillis());

				currentComponent = "tJava_2";

				int tos_count_tJava_2 = 0;

				System.out.println(context.storeproc
						+ " has been successfully completed");

				/**
				 * [tJava_2 begin ] stop
				 */

				/**
				 * [tJava_2 main ] start
				 */

				currentComponent = "tJava_2";

				tos_count_tJava_2++;

				/**
				 * [tJava_2 main ] stop
				 */

				/**
				 * [tJava_2 end ] start
				 */

				currentComponent = "tJava_2";

				ok_Hash.put("tJava_2", true);
				end_Hash.put("tJava_2", System.currentTimeMillis());

				/**
				 * [tJava_2 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_2 finally ] start
				 */

				currentComponent = "tJava_2";

				/**
				 * [tJava_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}

	public void tDie_4Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tDie_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tDie_4 begin ] start
				 */

				ok_Hash.put("tDie_4", false);
				start_Hash.put("tDie_4", System.currentTimeMillis());

				currentComponent = "tDie_4";

				int tos_count_tDie_4 = 0;

				if (log.isInfoEnabled())
					log.info("tDie_4 - " + "Start to work.");
				StringBuilder log4jParamters_tDie_4 = new StringBuilder();
				log4jParamters_tDie_4.append("Parameters:");
				log4jParamters_tDie_4.append("MESSAGE" + " = "
						+ "\"[ERROR] Database Connection Failed\"");
				log4jParamters_tDie_4.append(" | ");
				log4jParamters_tDie_4.append("CODE" + " = " + "4");
				log4jParamters_tDie_4.append(" | ");
				log4jParamters_tDie_4.append("PRIORITY" + " = " + "5");
				log4jParamters_tDie_4.append(" | ");
				log4jParamters_tDie_4.append("EXIT_JVM" + " = " + "false");
				log4jParamters_tDie_4.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tDie_4 - " + log4jParamters_tDie_4);

				/**
				 * [tDie_4 begin ] stop
				 */

				/**
				 * [tDie_4 main ] start
				 */

				currentComponent = "tDie_4";

				globalMap.put("tDie_4_DIE_PRIORITY", 5);
				System.err.println("[ERROR] Database Connection Failed");

				log.error("tDie_4 - The die message: "
						+ "[ERROR] Database Connection Failed");

				globalMap.put("tDie_4_DIE_MESSAGE",
						"[ERROR] Database Connection Failed");
				globalMap.put("tDie_4_DIE_MESSAGES",
						"[ERROR] Database Connection Failed");
				currentComponent = "tDie_4";
				status = "failure";
				errorCode = new Integer(4);
				globalMap.put("tDie_4_DIE_CODE", errorCode);

				if (true) {
					throw new TDieException();
				}

				tos_count_tDie_4++;

				/**
				 * [tDie_4 main ] stop
				 */

				/**
				 * [tDie_4 end ] start
				 */

				currentComponent = "tDie_4";

				if (log.isInfoEnabled())
					log.info("tDie_4 - " + "Done.");

				ok_Hash.put("tDie_4", true);
				end_Hash.put("tDie_4", System.currentTimeMillis());

				/**
				 * [tDie_4 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDie_4 finally ] start
				 */

				currentComponent = "tDie_4";

				/**
				 * [tDie_4 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDie_4_SUBPROCESS_STATE", 1);
	}

	public void tDie_5Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tDie_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tDie_5 begin ] start
				 */

				ok_Hash.put("tDie_5", false);
				start_Hash.put("tDie_5", System.currentTimeMillis());

				currentComponent = "tDie_5";

				int tos_count_tDie_5 = 0;

				if (log.isInfoEnabled())
					log.info("tDie_5 - " + "Start to work.");
				StringBuilder log4jParamters_tDie_5 = new StringBuilder();
				log4jParamters_tDie_5.append("Parameters:");
				log4jParamters_tDie_5.append("MESSAGE" + " = "
						+ "\"[ERROR] Invalid Command\"");
				log4jParamters_tDie_5.append(" | ");
				log4jParamters_tDie_5.append("CODE" + " = " + "4");
				log4jParamters_tDie_5.append(" | ");
				log4jParamters_tDie_5.append("PRIORITY" + " = " + "5");
				log4jParamters_tDie_5.append(" | ");
				log4jParamters_tDie_5.append("EXIT_JVM" + " = " + "false");
				log4jParamters_tDie_5.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tDie_5 - " + log4jParamters_tDie_5);

				/**
				 * [tDie_5 begin ] stop
				 */

				/**
				 * [tDie_5 main ] start
				 */

				currentComponent = "tDie_5";

				globalMap.put("tDie_5_DIE_PRIORITY", 5);
				System.err.println("[ERROR] Invalid Command");

				log.error("tDie_5 - The die message: "
						+ "[ERROR] Invalid Command");

				globalMap.put("tDie_5_DIE_MESSAGE", "[ERROR] Invalid Command");
				globalMap.put("tDie_5_DIE_MESSAGES", "[ERROR] Invalid Command");
				currentComponent = "tDie_5";
				status = "failure";
				errorCode = new Integer(4);
				globalMap.put("tDie_5_DIE_CODE", errorCode);

				if (true) {
					throw new TDieException();
				}

				tos_count_tDie_5++;

				/**
				 * [tDie_5 main ] stop
				 */

				/**
				 * [tDie_5 end ] start
				 */

				currentComponent = "tDie_5";

				if (log.isInfoEnabled())
					log.info("tDie_5 - " + "Done.");

				ok_Hash.put("tDie_5", true);
				end_Hash.put("tDie_5", System.currentTimeMillis());

				/**
				 * [tDie_5 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDie_5 finally ] start
				 */

				currentComponent = "tDie_5";

				/**
				 * [tDie_5 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDie_5_SUBPROCESS_STATE", 1);
	}

	public void tOracleRow_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleRow_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tOracleRow_1 begin ] start
				 */

				ok_Hash.put("tOracleRow_1", false);
				start_Hash.put("tOracleRow_1", System.currentTimeMillis());

				currentComponent = "tOracleRow_1";

				int tos_count_tOracleRow_1 = 0;

				if (log.isInfoEnabled())
					log.info("tOracleRow_1 - " + "Start to work.");
				StringBuilder log4jParamters_tOracleRow_1 = new StringBuilder();
				log4jParamters_tOracleRow_1.append("Parameters:");
				log4jParamters_tOracleRow_1.append("USE_EXISTING_CONNECTION"
						+ " = " + "true");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("CONNECTION" + " = "
						+ "tOracleConnection_1");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("QUERY" + " = "
						+ "context.Query");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("USE_NB_LINE" + " = "
						+ "NONE");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("DIE_ON_ERROR" + " = "
						+ "true");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("PROPAGATE_RECORD_SET"
						+ " = " + "false");
				log4jParamters_tOracleRow_1.append(" | ");
				log4jParamters_tOracleRow_1.append("USE_PREPAREDSTATEMENT"
						+ " = " + "false");
				log4jParamters_tOracleRow_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tOracleRow_1 - " + log4jParamters_tOracleRow_1);

				java.sql.Connection conn_tOracleRow_1 = null;
				String query_tOracleRow_1 = "";
				boolean whetherReject_tOracleRow_1 = false;
				conn_tOracleRow_1 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				if (conn_tOracleRow_1 != null) {
					if (conn_tOracleRow_1.getMetaData() != null) {

						log.info("tOracleRow_1 - Uses an existing connection with username '"
								+ conn_tOracleRow_1.getMetaData().getUserName()
								+ "'. Connection URL: "
								+ conn_tOracleRow_1.getMetaData().getURL()
								+ ".");

					}
				}

				java.sql.Statement stmt_tOracleRow_1 = conn_tOracleRow_1
						.createStatement();

				/**
				 * [tOracleRow_1 begin ] stop
				 */

				/**
				 * [tOracleRow_1 main ] start
				 */

				currentComponent = "tOracleRow_1";

				log.info("tOracleRow_1 - Executing the query: '"
						+ context.Query + "'.");

				query_tOracleRow_1 = context.Query;
				whetherReject_tOracleRow_1 = false;
				globalMap.put("tOracleRow_1_QUERY", query_tOracleRow_1);
				try {
					stmt_tOracleRow_1.execute(query_tOracleRow_1);

					log.info("tOracleRow_1 - Execute the query: '"
							+ context.Query + "' has finished.");

				} catch (java.lang.Exception e) {
					whetherReject_tOracleRow_1 = true;

					throw (e);

				}

				if (!whetherReject_tOracleRow_1) {

				}

				tos_count_tOracleRow_1++;

				/**
				 * [tOracleRow_1 main ] stop
				 */

				/**
				 * [tOracleRow_1 end ] start
				 */

				currentComponent = "tOracleRow_1";

				stmt_tOracleRow_1.close();

				if (log.isInfoEnabled())
					log.info("tOracleRow_1 - " + "Done.");

				ok_Hash.put("tOracleRow_1", true);
				end_Hash.put("tOracleRow_1", System.currentTimeMillis());

				/**
				 * [tOracleRow_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tOracleRow_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tOracleCommit_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleRow_1 finally ] start
				 */

				currentComponent = "tOracleRow_1";

				/**
				 * [tOracleRow_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleRow_1_SUBPROCESS_STATE", 1);
	}

	public void tDie_2Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tDie_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tDie_2 begin ] start
				 */

				ok_Hash.put("tDie_2", false);
				start_Hash.put("tDie_2", System.currentTimeMillis());

				currentComponent = "tDie_2";

				int tos_count_tDie_2 = 0;

				if (log.isInfoEnabled())
					log.info("tDie_2 - " + "Start to work.");
				StringBuilder log4jParamters_tDie_2 = new StringBuilder();
				log4jParamters_tDie_2.append("Parameters:");
				log4jParamters_tDie_2
						.append("MESSAGE"
								+ " = "
								+ "\"Load Failed for Query : \"+ context.Query + \" with error message :\"+((String)globalMap.get(\"tOracleInput_2_ERROR_MESSAGE\"))");
				log4jParamters_tDie_2.append(" | ");
				log4jParamters_tDie_2.append("CODE" + " = " + "4");
				log4jParamters_tDie_2.append(" | ");
				log4jParamters_tDie_2.append("PRIORITY" + " = " + "5");
				log4jParamters_tDie_2.append(" | ");
				log4jParamters_tDie_2.append("EXIT_JVM" + " = " + "false");
				log4jParamters_tDie_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tDie_2 - " + log4jParamters_tDie_2);

				/**
				 * [tDie_2 begin ] stop
				 */

				/**
				 * [tDie_2 main ] start
				 */

				currentComponent = "tDie_2";

				globalMap.put("tDie_2_DIE_PRIORITY", 5);
				System.err.println("Load Failed for Query : "
						+ context.Query
						+ " with error message :"
						+ ((String) globalMap
								.get("tOracleInput_2_ERROR_MESSAGE")));

				log.error("tDie_2 - The die message: "
						+ "Load Failed for Query : "
						+ context.Query
						+ " with error message :"
						+ ((String) globalMap
								.get("tOracleInput_2_ERROR_MESSAGE")));

				globalMap.put(
						"tDie_2_DIE_MESSAGE",
						"Load Failed for Query : "
								+ context.Query
								+ " with error message :"
								+ ((String) globalMap
										.get("tOracleInput_2_ERROR_MESSAGE")));
				globalMap.put(
						"tDie_2_DIE_MESSAGES",
						"Load Failed for Query : "
								+ context.Query
								+ " with error message :"
								+ ((String) globalMap
										.get("tOracleInput_2_ERROR_MESSAGE")));
				currentComponent = "tDie_2";
				status = "failure";
				errorCode = new Integer(4);
				globalMap.put("tDie_2_DIE_CODE", errorCode);

				if (true) {
					throw new TDieException();
				}

				tos_count_tDie_2++;

				/**
				 * [tDie_2 main ] stop
				 */

				/**
				 * [tDie_2 end ] start
				 */

				currentComponent = "tDie_2";

				if (log.isInfoEnabled())
					log.info("tDie_2 - " + "Done.");

				ok_Hash.put("tDie_2", true);
				end_Hash.put("tDie_2", System.currentTimeMillis());

				/**
				 * [tDie_2 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDie_2 finally ] start
				 */

				currentComponent = "tDie_2";

				/**
				 * [tDie_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDie_2_SUBPROCESS_STATE", 1);
	}

	public void tOracleCommit_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleCommit_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tOracleCommit_1 begin ] start
				 */

				ok_Hash.put("tOracleCommit_1", false);
				start_Hash.put("tOracleCommit_1", System.currentTimeMillis());

				currentComponent = "tOracleCommit_1";

				int tos_count_tOracleCommit_1 = 0;

				if (log.isInfoEnabled())
					log.info("tOracleCommit_1 - " + "Start to work.");
				StringBuilder log4jParamters_tOracleCommit_1 = new StringBuilder();
				log4jParamters_tOracleCommit_1.append("Parameters:");
				log4jParamters_tOracleCommit_1.append("CONNECTION" + " = "
						+ "tOracleConnection_1");
				log4jParamters_tOracleCommit_1.append(" | ");
				log4jParamters_tOracleCommit_1.append("CLOSE" + " = " + "true");
				log4jParamters_tOracleCommit_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tOracleCommit_1 - "
							+ log4jParamters_tOracleCommit_1);

				/**
				 * [tOracleCommit_1 begin ] stop
				 */

				/**
				 * [tOracleCommit_1 main ] start
				 */

				currentComponent = "tOracleCommit_1";

				java.sql.Connection conn_tOracleCommit_1 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				if (conn_tOracleCommit_1 != null
						&& !conn_tOracleCommit_1.isClosed()) {

					try {

						log.debug("tOracleCommit_1 - Connection 'tOracleConnection_1' starting to commit.");

						conn_tOracleCommit_1.commit();

						log.debug("tOracleCommit_1 - Connection 'tOracleConnection_1' commit has succeeded.");

					} finally {

						log.info("tOracleCommit_1 - Closing the connection 'tOracleConnection_1' to the database.");

						conn_tOracleCommit_1.close();

						log.info("tOracleCommit_1 - Connection 'tOracleConnection_1' to the database closed.");

					}

				}

				tos_count_tOracleCommit_1++;

				/**
				 * [tOracleCommit_1 main ] stop
				 */

				/**
				 * [tOracleCommit_1 end ] start
				 */

				currentComponent = "tOracleCommit_1";

				if (log.isInfoEnabled())
					log.info("tOracleCommit_1 - " + "Done.");

				ok_Hash.put("tOracleCommit_1", true);
				end_Hash.put("tOracleCommit_1", System.currentTimeMillis());

				/**
				 * [tOracleCommit_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tOracleCommit_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tJava_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tOracleCommit_1 finally ] start
				 */

				currentComponent = "tOracleCommit_1";

				/**
				 * [tOracleCommit_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tOracleCommit_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_1 begin ] start
				 */

				ok_Hash.put("tJava_1", false);
				start_Hash.put("tJava_1", System.currentTimeMillis());

				currentComponent = "tJava_1";

				int tos_count_tJava_1 = 0;

				System.out.println(context.cmd
						+ " has been successfully completed");

				/**
				 * [tJava_1 begin ] stop
				 */

				/**
				 * [tJava_1 main ] start
				 */

				currentComponent = "tJava_1";

				tos_count_tJava_1++;

				/**
				 * [tJava_1 main ] stop
				 */

				/**
				 * [tJava_1 end ] start
				 */

				currentComponent = "tJava_1";

				ok_Hash.put("tJava_1", true);
				end_Hash.put("tJava_1", System.currentTimeMillis());

				/**
				 * [tJava_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_1 finally ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}

	public void tDie_3Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tDie_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tDie_3 begin ] start
				 */

				ok_Hash.put("tDie_3", false);
				start_Hash.put("tDie_3", System.currentTimeMillis());

				currentComponent = "tDie_3";

				int tos_count_tDie_3 = 0;

				if (log.isInfoEnabled())
					log.info("tDie_3 - " + "Start to work.");
				StringBuilder log4jParamters_tDie_3 = new StringBuilder();
				log4jParamters_tDie_3.append("Parameters:");
				log4jParamters_tDie_3
						.append("MESSAGE"
								+ " = "
								+ "\"[ERROR] Sufficient Params are not provided. Min required params: USERNAME, PASSWORD, SCHEMA, DB URI\"");
				log4jParamters_tDie_3.append(" | ");
				log4jParamters_tDie_3.append("CODE" + " = " + "4");
				log4jParamters_tDie_3.append(" | ");
				log4jParamters_tDie_3.append("PRIORITY" + " = " + "5");
				log4jParamters_tDie_3.append(" | ");
				log4jParamters_tDie_3.append("EXIT_JVM" + " = " + "false");
				log4jParamters_tDie_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tDie_3 - " + log4jParamters_tDie_3);

				/**
				 * [tDie_3 begin ] stop
				 */

				/**
				 * [tDie_3 main ] start
				 */

				currentComponent = "tDie_3";

				globalMap.put("tDie_3_DIE_PRIORITY", 5);
				System.err
						.println("[ERROR] Sufficient Params are not provided. Min required params: USERNAME, PASSWORD, SCHEMA, DB URI");

				log.error("tDie_3 - The die message: "
						+ "[ERROR] Sufficient Params are not provided. Min required params: USERNAME, PASSWORD, SCHEMA, DB URI");

				globalMap
						.put("tDie_3_DIE_MESSAGE",
								"[ERROR] Sufficient Params are not provided. Min required params: USERNAME, PASSWORD, SCHEMA, DB URI");
				globalMap
						.put("tDie_3_DIE_MESSAGES",
								"[ERROR] Sufficient Params are not provided. Min required params: USERNAME, PASSWORD, SCHEMA, DB URI");
				currentComponent = "tDie_3";
				status = "failure";
				errorCode = new Integer(4);
				globalMap.put("tDie_3_DIE_CODE", errorCode);

				if (true) {
					throw new TDieException();
				}

				tos_count_tDie_3++;

				/**
				 * [tDie_3 main ] stop
				 */

				/**
				 * [tDie_3 end ] start
				 */

				currentComponent = "tDie_3";

				if (log.isInfoEnabled())
					log.info("tDie_3 - " + "Done.");

				ok_Hash.put("tDie_3", true);
				end_Hash.put("tDie_3", System.currentTimeMillis());

				/**
				 * [tDie_3 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDie_3 finally ] start
				 */

				currentComponent = "tDie_3";

				/**
				 * [tDie_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDie_3_SUBPROCESS_STATE", 1);
	}

	public static class row2Struct implements
			routines.system.IPersistableComparableLookupRow<row2Struct> {
		final static byte[] commonByteArrayLock_DI_DEMO_DBUtility = new byte[0];
		static byte[] commonByteArray_DI_DEMO_DBUtility = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String key;

		public String getKey() {
			return this.key;
		}

		public String value;

		public String getValue() {
			return this.value;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result
						+ ((this.key == null) ? 0 : this.key.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row2Struct other = (row2Struct) obj;

			if (this.key == null) {
				if (other.key != null)
					return false;

			} else if (!this.key.equals(other.key))

				return false;

			return true;
		}

		public void copyDataTo(row2Struct other) {

			other.key = this.key;
			other.value = this.value;

		}

		public void copyKeysDataTo(row2Struct other) {

			other.key = this.key;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DI_DEMO_DBUtility.length) {
					if (length < 1024
							&& commonByteArray_DI_DEMO_DBUtility.length == 0) {
						commonByteArray_DI_DEMO_DBUtility = new byte[1024];
					} else {
						commonByteArray_DI_DEMO_DBUtility = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DI_DEMO_DBUtility, 0, length);
				strReturn = new String(commonByteArray_DI_DEMO_DBUtility, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos,
				ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DI_DEMO_DBUtility) {

				try {

					int length = 0;

					this.key = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.key, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.value = readString(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeString(this.value, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("key=" + key);
			sb.append(",value=" + value);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (key == null) {
				sb.append("<null>");
			} else {
				sb.append(key);
			}

			sb.append("|");

			if (value == null) {
				sb.append("<null>");
			} else {
				sb.append(value);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.key, other.key);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();

				/**
				 * [tAdvancedHash_row2 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row2", false);
				start_Hash
						.put("tAdvancedHash_row2", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row2";

				int tos_count_tAdvancedHash_row2 = 0;

				// connection name:row2
				// source node:tFileInputDelimited_2 -
				// inputs:(after_tFileInputDelimited_1) outputs:(row2,row2) |
				// target node:tAdvancedHash_row2 - inputs:(row2) outputs:()
				// linked node: tMap_1 - inputs:(tns_alias,row2) outputs:(url)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row2 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row2Struct> getLookup(matchingModeEnum_row2);

				globalMap.put("tHash_Lookup_row2", tHash_Lookup_row2);

				/**
				 * [tAdvancedHash_row2 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2",
						System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				if (log.isInfoEnabled())
					log.info("tFileInputDelimited_2 - " + "Start to work.");
				StringBuilder log4jParamters_tFileInputDelimited_2 = new StringBuilder();
				log4jParamters_tFileInputDelimited_2.append("Parameters:");
				log4jParamters_tFileInputDelimited_2.append("FILENAME" + " = "
						+ "context.tnsfile");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("CSV_OPTION"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("ROWSEPARATOR"
						+ " = " + "\"\\n\"");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("FIELDSEPARATOR"
						+ " = " + "\"~~\"");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("HEADER" + " = "
						+ "0");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("FOOTER" + " = "
						+ "0");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("LIMIT" + " = "
						+ "");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("REMOVE_EMPTY_ROW"
						+ " = " + "true");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("UNCOMPRESS"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("DIE_ON_ERROR"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2
						.append("ADVANCED_SEPARATOR" + " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("RANDOM" + " = "
						+ "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("TRIMALL" + " = "
						+ "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("TRIMSELECT"
						+ " = " + "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("key") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("value") + "}]");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("CHECK_FIELDS_NUM"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("CHECK_DATE"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("SPLITRECORD"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				log4jParamters_tFileInputDelimited_2.append("ENABLE_DECODE"
						+ " = " + "false");
				log4jParamters_tFileInputDelimited_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_2 - "
							+ log4jParamters_tFileInputDelimited_2);

				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				try {

					Object filename_tFileInputDelimited_2 = context.tnsfile;
					if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
						if (footer_value_tFileInputDelimited_2 > 0
								|| random_value_tFileInputDelimited_2 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(
								context.tnsfile, "ISO-8859-15", "~~", "\n",
								true, 0, 0, -1, -1, false);
					} catch (java.lang.Exception e) {

						log.error("tFileInputDelimited_2 - " + e.getMessage());

						System.err.println(e.getMessage());

					}

					log.info("tFileInputDelimited_2 - Retrieving records from the datasource.");

					while (fid_tFileInputDelimited_2 != null
							&& fid_tFileInputDelimited_2.nextRecord()) {

						row2 = null;

						row2 = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						row2 = new row2Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_2 = 0;

							columnIndexWithD_tFileInputDelimited_2 = 0;

							row2.key = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 1;

							row2.value = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

						} catch (java.lang.Exception e) {
							whetherReject_tFileInputDelimited_2 = true;

							log.error("tFileInputDelimited_2 - "
									+ e.getMessage());

							System.err.println(e.getMessage());
							row2 = null;

						}

						log.debug("tFileInputDelimited_2 - Retrieving the record "
								+ fid_tFileInputDelimited_2.getRowNumber()
								+ ".");

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */
						// Start of branch "row2"
						if (row2 != null) {

							/**
							 * [tAdvancedHash_row2 main ] start
							 */

							currentComponent = "tAdvancedHash_row2";

							if (log.isTraceEnabled()) {
								log.trace("row2 - "
										+ (row2 == null ? "" : row2
												.toLogString()));
							}

							row2Struct row2_HashRow = new row2Struct();

							row2_HashRow.key = row2.key;

							row2_HashRow.value = row2.value;

							tHash_Lookup_row2.put(row2_HashRow);

							tos_count_tAdvancedHash_row2++;

							/**
							 * [tAdvancedHash_row2 main ] stop
							 */

						} // End of branch "row2"

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

					}
				} finally {
					if (!((Object) (context.tnsfile) instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_2 != null) {
							fid_tFileInputDelimited_2.close();
						}
					}
					if (fid_tFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE",
								fid_tFileInputDelimited_2.getRowNumber());

						log.info("tFileInputDelimited_2 - Retrieved records count: "
								+ fid_tFileInputDelimited_2.getRowNumber()
								+ ".");

					}
				}

				if (log.isInfoEnabled())
					log.info("tFileInputDelimited_2 - " + "Done.");

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2",
						System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tAdvancedHash_row2 end ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				tHash_Lookup_row2.endPut();

				ok_Hash.put("tAdvancedHash_row2", true);
				end_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row2 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row2 finally ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				/**
				 * [tAdvancedHash_row2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private java.util.Properties context_param = new java.util.Properties();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final DBUtility DBUtilityClass = new DBUtility();

		int exitCode = DBUtilityClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'DBUtility' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = (String[][]) globalBuffer
				.toArray(new String[globalBuffer.size()][]);

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		hastBufferOutput = true;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (!"".equals(log4jLevel)) {
			if ("trace".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.OFF);
			}
			org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
		}
		log.info("TalendJob: 'DBUtility' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		try {
			// call job/subjob with an existing context, like:
			// --context=production. if without this parameter, there will use
			// the default context instead.
			java.io.InputStream inContext = DBUtility.class.getClassLoader()
					.getResourceAsStream(
							"di_demo/dbutility_0_3/contexts/" + contextStr
									+ ".properties");
			if (isDefaultContext && inContext == null) {

			} else {
				if (inContext != null) {
					// defaultProps is in order to keep the original context
					// value
					defaultProps.load(inContext);
					inContext.close();
					context = new ContextProperties(defaultProps);
				} else {
					// print info and job continue to run, for case:
					// context_param is not empty.
					System.err.println("Could not find the context "
							+ contextStr);
				}
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
			}
			context.username = (String) context.getProperty("username");
			String pwd_password_value = context.getProperty("password");
			context.password = null;
			if (pwd_password_value != null) {
				if (context_param.containsKey("password")) {// no need to
															// decrypt if it
															// come from program
															// argument or
															// parent job
															// runtime
					context.password = pwd_password_value;
				} else if (!pwd_password_value.isEmpty()) {
					try {
						context.password = routines.system.PasswordEncryptUtil
								.decryptPassword(pwd_password_value);
						context.put("password", context.password);
					} catch (java.lang.RuntimeException e) {
						// do nothing
					}
				}
			}
			context.port = (String) context.getProperty("port");
			context.Query = (String) context.getProperty("Query");
			context.host = (String) context.getProperty("host");
			context.Schema = (String) context.getProperty("Schema");
			context.cmd = (String) context.getProperty("cmd");
			context.database = (String) context.getProperty("database");
			context.storeproc = (String) context.getProperty("storeproc");
			context.filepath = (String) context.getProperty("filepath");
			context.filename = (String) context.getProperty("filename");
			context.tnsfile = (String) context.getProperty("tnsfile");
			context.url = (String) context.getProperty("url");
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("username")) {
				context.username = (String) parentContextMap.get("username");
			}
			if (parentContextMap.containsKey("password")) {
				context.password = (java.lang.String) parentContextMap
						.get("password");
			}
			if (parentContextMap.containsKey("port")) {
				context.port = (String) parentContextMap.get("port");
			}
			if (parentContextMap.containsKey("Query")) {
				context.Query = (String) parentContextMap.get("Query");
			}
			if (parentContextMap.containsKey("host")) {
				context.host = (String) parentContextMap.get("host");
			}
			if (parentContextMap.containsKey("Schema")) {
				context.Schema = (String) parentContextMap.get("Schema");
			}
			if (parentContextMap.containsKey("cmd")) {
				context.cmd = (String) parentContextMap.get("cmd");
			}
			if (parentContextMap.containsKey("database")) {
				context.database = (String) parentContextMap.get("database");
			}
			if (parentContextMap.containsKey("storeproc")) {
				context.storeproc = (String) parentContextMap.get("storeproc");
			}
			if (parentContextMap.containsKey("filepath")) {
				context.filepath = (String) parentContextMap.get("filepath");
			}
			if (parentContextMap.containsKey("filename")) {
				context.filename = (String) parentContextMap.get("filename");
			}
			if (parentContextMap.containsKey("tnsfile")) {
				context.tnsfile = (String) parentContextMap.get("tnsfile");
			}
			if (parentContextMap.containsKey("url")) {
				context.url = (String) parentContextMap.get("url");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		parametersToEncrypt.add("password");
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "",
				resumeUtil.convertToJsonText(context, parametersToEncrypt));

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : DBUtility");
		}

		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "" + returnCode, "",
				"", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {
		closeSqlDbConnections();

	}

	private void closeSqlDbConnections() {
		try {
			Object obj_conn;
			obj_conn = globalMap.remove("conn_tOracleConnection_1");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
		} catch (java.lang.Exception e) {
		}
	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
		connections.put("conn_tOracleConnection_1",
				globalMap.get("conn_tOracleConnection_1"));

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		}

	}

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" },
			{ "\\'", "\'" }, { "\\r", "\r" }, { "\\f", "\f" }, { "\\b", "\b" },
			{ "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex,
							index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left
			// into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 179729 characters generated by Talend Real-time Big Data Platform on the
 * March 8, 2017 1:18:39 PM EST
 ************************************************************************************************/
