package routines;


public class StringHandler {

    
    public static String RemoveSpecialchars(String Str) {
        if (Str != null) {
        	Str=Str.trim();   //[^-\\dA-Za-zà-ùÀ-Ùá-úýÁ-ÚÝâ-ûÂ-ÛãñõÃÑÕä-üÿÄ-ÜåÅçÇæÆðÐøØß`~!@#$%^&*()_+=[{]{}:;|<\\\\,>.?/ ]
        	Str=Str.replaceAll("[^-\\dA-Za-zà-ùÀ-Ùá-úýÁ-ÚÝâ-ûÂ-ÛãñõÃÑÕä-üÿÄ-ÜåÅçÇæÆðÐøØß`~!@#$%^&*()_+=\\[\\]{}:;|<\\\\,>.?/ ]","");
        }
        return Str; //$NON-NLS-1$ //$NON-NLS-2$
    }
}
