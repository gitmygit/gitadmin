package routines;

import java.math.BigDecimal;
import java.math.BigInteger;



public class BigDecimalConvertion {
  
	static boolean fb=false;
	static String item ="";
	
	public static BigDecimal GetValFromZDStr(String pZDValue, int pScale)
	{
		  BigDecimal result=null;
		  String shortString="0";
		  int value=0;
		  double defval=0;
		  if(pZDValue!=null && pZDValue.trim().length()>0)//A has value then 
		  {
			  switch(pZDValue.charAt(pZDValue.length()-1))//B has a ZonedValue then
			  {
				  case '{':pZDValue.replace('{', '0'); break;
				  case 'A':pZDValue.replace('A', '1'); break;
				  case 'B':pZDValue.replace('B', '2'); break;
				  case 'C':pZDValue.replace('C', '3'); break;
				  case 'D':pZDValue.replace('D', '4'); break;
				  case 'E':pZDValue.replace('E', '5'); break;
				  case 'F':pZDValue.replace('F', '6'); break;
				  case 'G':pZDValue.replace('G', '7'); break;
				  case 'H':pZDValue.replace('H', '8'); break;
				  case 'I':pZDValue.replace('I', '9'); break;
				  case '}':pZDValue="-"+pZDValue.replace('}', '0'); break;
				  case 'J':pZDValue="-"+pZDValue.replace('J', '1'); break;
				  case 'K':pZDValue="-"+pZDValue.replace('K', '2'); break;
				  case 'L':pZDValue="-"+pZDValue.replace('L', '3'); break;
				  case 'M':pZDValue="-"+pZDValue.replace('M', '4'); break;
				  case 'N':pZDValue="-"+pZDValue.replace('N', '5'); break;
				  case 'O':pZDValue="-"+pZDValue.replace('O', '6'); break;
				  case 'P':pZDValue="-"+pZDValue.replace('P', '7'); break;
				  case 'Q':pZDValue="-"+pZDValue.replace('Q', '8'); break;
				  case 'R':pZDValue="-"+pZDValue.replace('R', '9'); break;
				  default:value=10;break;
			  }//close B
			  
	          if(value!=10)//default if
	          {
	        	  if(pScale !=0)
				  {
					  shortString =SetScaleToString(pZDValue, pScale) ;//
					  //System.out.println(shortString);
				  }
	        	  else 
	        	  {
	        		  shortString =pZDValue;
	        	  }
	        	  if(BigDecimalStr(shortString)!=null)
					  result= new BigDecimal(BigDecimalStr(shortString));
				  else 
					  result= new BigDecimal("0");
 	  
	          }
	          else 
	          {
	        	  if(pScale !=0)
				  {
					  shortString =SetScaleToString(pZDValue, pScale) ;//
				  }
	        	  else 
	        	  {
	        		  shortString =pZDValue;//
	        	  }
	        	  if(BigDecimalStr(shortString)!=null)
					  result= new BigDecimal(BigDecimalStr(shortString));
				  else 
					  result= new BigDecimal("0");
	          }//default if close
		  }// close A
		  else 
		  {
			  result=(new BigDecimal(defval));
		  }
		  //System.out.println(result);
		  return result;
	}
	/**

	* 

	* @param bdValue input string BigDecimal String format.

	* @param scale input int scale format.

	* @return BigDecimal value.

	* 

	* {talendTypes} BigDecimal

	* 

	* {Category} BigDecimal

	* 

	* {param} string("12121212") bdValue : input string BigDecimalConvertion.BigDecimalStr("12121") format

	* 

	* {param} string(3) scale : return Int format

	* 

	* {example} BigDecimalConvertion.SetScaleToBigDecimal(BigDecimalConvertion.BigDecimalStr("12121"),3) #

	*/


	public static BigDecimal SetScaleToBigDecimal(String bdValue, int scale)

	{

		BigDecimal result=null;
	
		if(bdValue!=null)
	
		{
	
		BigInteger bi = new BigInteger(bdValue);
	
		result = new BigDecimal(bi,scale);
	
		}
	
		return result;

	}


	public static String SetScaleToString(String pInputString,int decimalPosition)
    {
            String result=pInputString;
            
            if(pInputString!=null && pInputString!="")
            {                    
                        String dfloat="0000000000001";  
                    	BigDecimal bval= new BigDecimal(routines.BigDecimalConvertion.BigDecimalStr(pInputString));
                    	String left=dfloat.substring(0, dfloat.length()-decimalPosition);
                        String right=dfloat.replace(left,"");
                        BigDecimal dval= new BigDecimal("0."+right);
                        return (bval.multiply(dval).toString());
                    	/* String left=pInputString.substring(0, pInputString.length()-decimalPosition);
                            String right=pInputString.replace(left,"");
                            result=left+"."+right;   */               
           }
            else 
            {
                    result="0";
            }
            
            return result;
    }

    public static String BigDecimalStr(String BG) {
    	
    	fb=false;
    	if( BG==null)
    	{
    		//System.out.println("1Final String  "+BG);
        		return item="0";
        }
    	else
    		if(BG.equalsIgnoreCase("#N/A") || BG.isEmpty() || BG.equals("")|| BG.equals(" ") || BG.length()<1)
    	{
    		return "0";
    	}
    	else
    	{
    		BG=BG.toUpperCase();
    		
    		if (BG.endsWith("-"))
    		{
    			fb=true;
    			BG=BG.replace("-","");
    			
    		}
    	if(BG.matches("^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$")==true)//    		if(BG.matches("^[0-9-+.]*$")==true)
    	{
    		if(BG.matches("^[0-9-.]*$")==true)
			{
				//BG=BG.replace("-","");
				//fb=true;
				//if(fb==true)BG="-"+BG;
				item=BG;
				//System.out.println("2Final String  "+item);
				//return (BG);
			}
			else
				if(BG.matches("^[0-9+.]*$")==true)
				{
					BG=BG.replace("+","");
					item=BG;
					//System.out.println("3Final String  "+item);
    				// return (BG);
				}
			else
			{

				//return (BG);
				
				item=BG;
				//System.out.println("6Final String  "+item);
			}
    	}
    		else if(BG.length()>0)
    		{
    			String S=BG;
    			String S1;
    			if(Character.toString(S.charAt(0) ).matches("[0-9-]")==false)
    			{
    				S1=S.replaceFirst(".+?(?=(\\d|[a-f-]))","");
    			}
    			else
    			{
    			S1=S;
    			}
    			//System.out.println("Value in S1 : "+ S1);
    			int len=0;
    			for(int i=0;i<S1.length();++i)
    			  {
    			  
    			  
    			  if((Character.toString(S1.charAt(i) ).matches("[0-9\\.-]"))==false)
    			  {
    			    break;
    			  }
    			  len=i+1;
    			}

    			//replace all alphabets from input string
    			S1=S1.replaceAll("^[a-zA-Z]+$", "");//str.replaceAll("[^\\d.]", "");
    			
    			 //System.out.println("12Final String  "+S1.substring(0,len ));
        		//return 
        		item=(S1.substring(0,len ));
        		
        		if(item.isEmpty()||item.length()==0)
        			{
        			if(S1.isEmpty()|| S1.length()==0 )
        					//|| (BG.matches("^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$")==false))
        			
        			S1="0";
        			
        			item=S1;
        			
        			}
        		//System.out.println("4Final String  "+item);
    		}
    		/*else
    		{
    			BG="0";
    		}*/
    	//System.out.println("Final String  "+item);
    	   
    	if(fb==true)
    		{
    		item="-"+item.trim();
    		//BigDecimal bd =  new BigDecimal(item);
    		fb=false;
    		
    		}
    	if((item.matches("^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$")==true))
    	{
    		item=item;
    	}
    	else
    	{
    		item="0";
    	}
    	//BigDecimal bd =  new BigDecimal(item);
    	return item;
    		}
    }
}
