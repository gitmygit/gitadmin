package routines;

import java.math.BigDecimal;
import java.util.Date;



/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class StrFunc {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static void helloExample(String message) {
        if (message == null) {
            message = "World"; //$NON-NLS-1$
        }
        System.out.println("Hello " + message + " !"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
	public static String trunc(String str, int len){
		return (!Relational.ISNULL(str) ? str : "none").substring(0,(str.length() > len ? len : str.length()));	
    }    

	public static String nullCheck(String str){
		return (!Relational.ISNULL(str) ? str : "none");	

    }    
	
	public static BigDecimal nullIdCheck(BigDecimal id){
		return 	(!Relational.ISNULL(id) &&  id != new BigDecimal(0)) ? id : new BigDecimal(-1);	

    }    
	
	public static BigDecimal nullMetricCheck(BigDecimal id){
		return 	(!Relational.ISNULL(id) &&  id != new BigDecimal(0)) ? id : new BigDecimal(0);	

    }    
	
	public static Integer nullIntegerCheck(Integer id){
		return 	!Relational.ISNULL(id) ? id : new Integer(0);	

    }    
	
	public static Integer nullBigD2IntegerCheck(BigDecimal id){
		return 	!Relational.ISNULL(id)? Integer.valueOf(id.intValue()) : new Integer(0);	

    }    
	
	public static boolean nullDateCheck(Date bdt, Date edt){
	return (TalendDate.compareDate(edt, bdt) == 1 
			|| TalendDate.compareDate(edt, bdt) == 0) 
			&& (TalendDate.compareDate(edt, 
					(TalendDate.compareDate(edt, 
							TalendDate.parseDate("yyyy-MM-dd","2999-01-01")) == -1 ? 
									edt : TalendDate.parseDate("yyyy-MM-dd","2999-01-02"))) == -1);
	
	}

	public static BigDecimal dayCheck(Date dt){
		return 	!Relational.ISNULL(dt) ? new BigDecimal(TalendDate.getPartOfDate("DAY_OF_MONTH",dt)) : new BigDecimal(-1);	

    }    
	
	public static BigDecimal monthCheck(Date dt){
		return 	!Relational.ISNULL(dt) ? new BigDecimal(TalendDate.getPartOfDate("MONTH",dt) + 1) : new BigDecimal(-1);	

    }    
	
	public static BigDecimal yearCheck(Date dt){
		return 	!Relational.ISNULL(dt) ? new BigDecimal(TalendDate.getPartOfDate("YEAR",dt)) : new BigDecimal(-1);	

    }    
	
	
	
}
