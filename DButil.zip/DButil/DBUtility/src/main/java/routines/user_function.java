package routines;

import java.util.Date;
/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class user_function {

    /**
     * validateValue: Removes dummy value "'N.A.' 'N.D.' 'N.S.'"
     *
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string("") Str: string.
     *
     *
     * {example} validateValue("First_str") # User defined function
     */
    public static String validateValue(String Var1) {
        if(Var1 == null){
        	return null; 
        }
        else if (Var1.compareTo("N.A.") == 0 || Var1.compareTo("N.D.") == 0  || Var1.compareTo("N.S.") == 0  ) {
            return null; 
        }
        else{
        	return Var1;
        }
       
    }
    
    public static float value_signage_func(float Var1,String in_sign, String status) {
        if("?".equals(in_sign) || "N/A".equals(in_sign)) {
        	return Var1; 
        }
        else if ("+".equals(in_sign) && ! "Cncl".equals(status)  ) {
            return Math.abs(Var1); 
        }
        else if ("+".equals(in_sign) && "Cncl".equals(status)  ) {
            return Math.abs(Var1) * -1; 
        }
        else if ("-".equals(in_sign) && ! "Cncl".equals(status)  ) {
            return Math.abs(Var1) * -1; 
        }
        else if ("-".equals(in_sign) && "Cncl".equals(status)  ) {
            return Math.abs(Var1); 
        }
        else{
        	return Var1;
        }
       
    }
    
    public static String clovConcat(String Var1, String Var2,String Var3,String Var4,String Var5,String Var6, float Var7) {
    	String return_val="";
        if (Var1 != null && ! "".equals(Var1)) {
        	return_val=Var1; 
        }else 
        	return_val="ALL"; 	
        
        if(Var2 != null && ! "".equals(Var2) ){
        	return_val=return_val + "|" + Var2;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        
        if(Var3 != null && ! "".equals(Var3) ){
        	return_val=return_val + "|" + Var3;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        
        if(Var4 != null && ! "".equals(Var4) ){
        	return_val=return_val + "|" + Var4;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        if(Var5 != null && ! "".equals(Var5) ){
        	return_val=return_val + "|" + Var5;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        if(Var6 != null && ! "".equals(Var6) ){
        	return_val=return_val + "|" + Var6;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        if( Var7 != 0 ){
        	return_val=return_val + "|" + "!0";
        }
        else{
        	return_val=return_val + "|" + "0";
        }
        
        return return_val;
       
    }
    
    public static String clovConcat(String Var1, String Var2,String Var3,String Var4,String Var5,String Var6) {
    	String return_val="";
        if (Var1 != null && ! "".equals(Var1)) {
        	return_val=Var1; 
        }else 
        	return_val="ALL"; 	
        
        if(Var2 != null && ! "".equals(Var2) ){
        	return_val=return_val + "|" + Var2;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        
        if(Var3 != null && ! "".equals(Var3) ){
        	return_val=return_val + "|" + Var3;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        
        if(Var4 != null && ! "".equals(Var4) ){
        	return_val=return_val + "|" + Var4;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        if(Var5 != null && ! "".equals(Var5) ){
        	return_val=return_val + "|" + Var5;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        if(Var6 != null && ! "".equals(Var6) ){
        	return_val=return_val + "|" + Var6;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
   
        return return_val;
       
    }
    
    public static String clovConcat(String Var1, String Var2,String Var3,String Var4,String Var5) {
    	String return_val="";
        if (Var1 != null && ! "".equals(Var1)) {
        	return_val=Var1; 
        }else 
        	return_val="ALL"; 	
        
        if(Var2 != null && ! "".equals(Var2) ){
        	return_val=return_val + "|" + Var2;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        
        if(Var3 != null && ! "".equals(Var3) ){
        	return_val=return_val + "|" + Var3;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        
        if(Var4 != null && ! "".equals(Var4) ){
        	return_val=return_val + "|" + Var4;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }
        if(Var5 != null && ! "".equals(Var5) ){
        	return_val=return_val + "|" + Var5;
        }
        else{
        	return_val=return_val + "|" + "ALL";
        }

   
        return return_val;
       
    }
    
    public static String clovConfrimStatus(String Var1) {
    	if("N".equals(Var1)){
    		return "N";
    	}
        else{
        	return "ALL";
        }
      
    } 
    
    public static Integer compareValue(String Var1, String Var2) {
        if(Var1 == null && Var2 == null){
        	return 0;
        }
    	else if ((Var1 == null && Var2 != null) || (Var1 != null && Var2 == null)) {
            return 1; 
        }
        else if (! Var1.equals(Var2) ) {
        	return 1;
        }
        
        else
        {
        	return 0;
        }
      
    }
    
    public static Integer compareValue(Float Var1, Float Var2) {
    	if(Var1 == null && Var2 == null){
    		return 0;
    	}
    	else if ((Var1 == null && Var2 != null) || (Var1 != null && Var2 == null) ) {
            return 1; 
        } else if (Var1.compareTo(Var2) == 1 ){
           return 1; 
        }
        else{
        	return 0;
        }
      
    }  
    
    public static Integer compareValue(Integer Var1, Integer Var2) {
    	if(Var1 == null && Var2 == null){
    		return 0;
    	}
    	else if ((Var1 == null && Var2 != null) || (Var1 != null && Var2 == null) ) {
            return 1; 
        }  else if (Var1.compareTo(Var2) == 1 ){
            return 1; 
        }
        else{
        	return 0;
        }
      
    }
    
    public static Integer compareValue(Date Var1, Date Var2) {
    	if ((Var1 == null && Var2 == null)){
    		return 0;
    	}
    	else if ((Var1 == null && Var2 != null) || (Var1 != null && Var2 == null) ) {
            return 1; 
        } else if (Var1.compareTo(Var2) == 1 ){
            return 1; 
        }
        else{
        	return 0;
        }
      
    }  
    
    public static String tradeStausCD(String Var1) {
        if(Var1 == null){
        	return null; 
        }
        else if ("REVRS".equals(Var1) ) {
            return "30"; 
        }
        else{
        	return "20";
        }
       
    }
	
    /**
     * FirstDefineStr: Returns First non null field
     *
     *
     * {talendTypes} String
     *
     * {Category} User Defined
     *
     * {param} string("") First_str: The First string.
     *
     * {param} string("") Second_str: The Second string.
     *
     * {example} firstDefinedStr("First_str", 'Second_str') # User defined function
     */
    public static String firstDefined(String Var1, String Var2) {
        if (Var1 != null && ! "".equals(Var1)) {
            return Var1; 
        }
        else if(Var2 != null && ! "".equals(Var2) ){
        	return Var2;
        }
        else{
        	return null;
        }
       
    }
    /**
     * firstDefinedInt: Returns First non null field
     *
     *
     * {talendTypes} Integer
     *
     * {Category} User Defined
     *
     * {param} Integer(0) First_Int: The First string.
     *
     * {param} Integer(0) Second_Int: The Second string.
     *
     * {example} firstDefinedInt("First_str", 'Second_str') # User defined function
     */
    public static Integer firstDefined(Integer Var1, Integer Var2) {
        if (Var1 != null) {
            return Var1; 
        }
        else if(Var2 != null){
        	return Var2;
        }
        else{
        	return null;
        }
       
    }    
    public static Double firstDefined(Double Var1, Double Var2) {
        if (Var1 != null) {
            return Var1; 
        }
        else if(Var2 != null){
        	return  Var2 ;
        }
        else{
        	return null;
        }
       
    }   
    
    public static Float firstDefined(Float Var1, Float Var2) {
        if (Var1 != null) {
            return Var1; 
        }
        else if(Var2 != null){
        	return  Var2 ;
        }
        else{
        	return null;
        }
       
    }   
    /**
     * firstDefinedDate: Returns First non null field
     *
     *
     * {talendTypes} Date
     *
     * {Category} User Defined
     *
     * {param} Date(2015-12-01) First_Dt: The First string.
     *
     * {param} Date(2015-12-01) Second_Dt: The Second string.
     *
     * {example} firstDefinedInt("First_str", 'Second_str') # User defined function
     */
    public static Date firstDefined(Date Var1, Date Var2) {
        if (Var1 != null) {
            return Var1; 
        }
        else if(Var2 != null){
        	return Var2;
        }
        else{
        	return null;
        }
       
    }      
   
}
