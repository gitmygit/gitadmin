#!/bin/sh
cd `dirname $0`
ROOT_PATH=`pwd`
#export WILY_AGENT_PATH="-javaagent:/opt/wily/introscopeagent/9.7.1.0/Agent.jar"
#export WILY_PROFILE="-Dcom.wily.introscope.agentProfile=/opt/wily/introscopeagent/9.7.1.0/core/config/ICGTBSTE.IntroscopeAgent.standalone.profile"
#export WILY_AGENT_NAME="-Dcom.wily.introscope.agent.agentName=${USER}_wily"

if [[ -n $CONTEXT_FILE_PATH ]]; then
        export CONTEXT_FILE=$CONTEXT_FILE_PATH
else
        export CONTEXT_FILE=/tdgiw/globalparams/
fi

java -Xms256M -Xmx1024M -cp .:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/antlr-runtime-3.5.2.jar:$ROOT_PATH/../lib/ojdbc6.jar:$ROOT_PATH/../lib/commons-collections-3.2.jar:$ROOT_PATH/../lib/log4j-1.2.15.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH/../lib/talend_file_enhanced_20070724.jar:$ROOT_PATH/../lib/trove.jar:$ROOT_PATH/../lib/talend-oracle-timestamptz.jar:$ROOT_PATH/../lib/org.talend.dataquality.parser.jar:$ROOT_PATH/../lib/tns.jar:$ROOT_PATH/../lib/advancedPersistentLookupLib-1.0.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/camel-core-2.15.3.jar:$ROOT_PATH/../lib/jboss-serialization.jar:$ROOT_PATH/dbutility_0_3.jar: di_demo.dbutility_0_3.DBUtility --context=Default "$@" --context_param tnsfile=${CONTEXT_FILE}/tnsnames.properties --context_param filepath=$CONTEXT_FILE
